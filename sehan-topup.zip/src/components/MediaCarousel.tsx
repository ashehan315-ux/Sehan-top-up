import React, { useState, useEffect, useRef } from "react";
import { CarouselItem } from "../types";
import { ChevronLeft, ChevronRight, Play, Pause, ExternalLink, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface MediaCarouselProps {
  items: CarouselItem[];
}

export default function MediaCarousel({ items }: MediaCarouselProps) {
  const activeItems = items.filter(item => item.active).sort((a, b) => a.order - b.order);
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [progress, setProgress] = useState(0);

  const slideDuration = 6000; // 6 seconds per slide

  // Reset current index if list changes and index is out of bounds
  useEffect(() => {
    if (currentIndex >= activeItems.length) {
      setCurrentIndex(0);
    }
  }, [activeItems.length, currentIndex]);

  // Handle slide timing and progress bar
  useEffect(() => {
    if (activeItems.length <= 1) {
      setProgress(100);
      return;
    }

    if (timerRef.current) clearInterval(timerRef.current);
    if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);

    if (isPlaying) {
      setProgress(0);
      const start = Date.now();
      
      progressIntervalRef.current = setInterval(() => {
        const elapsed = Date.now() - start;
        const computedProgress = Math.min((elapsed / slideDuration) * 100, 100);
        setProgress(computedProgress);
      }, 50);

      timerRef.current = setTimeout(() => {
        handleNext();
      }, slideDuration);
    }

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, [currentIndex, isPlaying, activeItems.length]);

  if (activeItems.length === 0) {
    return (
      <div className="relative p-10 rounded-3xl bg-gradient-to-r from-cyan-950/20 to-blue-950/10 border border-white/5 text-center py-16">
        <Sparkles className="w-10 h-10 text-cyan-500/50 mx-auto mb-3 animate-pulse" />
        <h3 className="text-white font-bold text-lg">SEHAN TOPUP INSTANT PORTAL</h3>
        <p className="text-slate-400 text-xs mt-1 max-w-md mx-auto">
          Welcome to Sri Lanka's premium automated game store. Place your order below for lightning-fast top-up processing!
        </p>
      </div>
    );
  }

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev === 0 ? activeItems.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev === activeItems.length - 1 ? 0 : prev + 1));
  };

  const currentItem = activeItems[currentIndex];

  const slideVariants = {
    enter: {
      opacity: 0
    },
    center: {
      opacity: 1,
      transition: {
        opacity: { duration: 0.8, ease: "easeInOut" }
      }
    },
    exit: {
      opacity: 0,
      transition: {
        opacity: { duration: 0.8, ease: "easeInOut" }
      }
    }
  };

  return (
    <div 
      className="relative rounded-3xl border border-white/10 overflow-hidden shadow-2xl h-[300px] sm:h-[380px] bg-slate-950/80 group"
      id="media-carousel-viewport"
    >
      {/* Dynamic Animated Glowing Grid Background */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#083344_1px,transparent_1px),linear-gradient(to_bottom,#083344_1px,transparent_1px)] bg-[size:4rem_4rem]" />
        <div className="absolute inset-0 bg-radial-gradient from-transparent via-transparent to-slate-950" />
      </div>

      {/* Cyberpunk Ambient Light Flares */}
      <div className="absolute -top-16 -left-16 w-56 h-56 bg-cyan-500/10 rounded-full blur-[80px] pointer-events-none animate-pulse" />
      <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-purple-500/10 rounded-full blur-[100px] pointer-events-none" style={{ animationDuration: "8s" }} />

      {/* Background Media Container with AnimatePresence */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden">
        <AnimatePresence initial={false} custom={direction} mode="popLayout">
          <motion.div
            key={currentItem.id}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            className="absolute inset-0 w-full h-full"
          >
            {/* Ambient Dark Overlays for ultimate readability and premium movie feel */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-black/30 z-10" />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-950/40 to-transparent z-10 hidden sm:block" />

            {currentItem.type === "video" ? (
              <motion.video
                initial={{ scale: 1.15, y: 0 }}
                animate={{ 
                  scale: [1.15, 1.03],
                  y: [0, -3, 0]
                }}
                transition={{ 
                  duration: 8, 
                  ease: "easeOut",
                  repeat: Infinity,
                  repeatType: "mirror"
                }}
                src={currentItem.url}
                className="w-full h-full object-cover"
                autoPlay
                muted
                loop
                playsInline
                referrerPolicy="no-referrer"
              />
            ) : (
              <motion.img
                initial={{ scale: 1.15, y: 0 }}
                animate={{ 
                  scale: [1.15, 1.03],
                  y: [0, -3, 0]
                }}
                transition={{ 
                  duration: 8, 
                  ease: "easeOut",
                  repeat: Infinity,
                  repeatType: "mirror"
                }}
                src={currentItem.url}
                alt={currentItem.title || "Game Banner"}
                className="w-full h-full object-cover select-none"
                referrerPolicy="no-referrer"
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Floating Sparkle / Media Type Badge */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          key={`badge-${currentItem.id}`}
          className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-slate-950/80 border border-cyan-500/30 text-[10px] font-black text-cyan-400 uppercase tracking-widest backdrop-blur-md shadow-lg shadow-black/40"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
          </span>
          <span className="font-mono">{currentItem.type === "video" ? "🎮 LIVE TEASER" : "🔥 TOP DEALS"}</span>
        </motion.div>
      </div>

      {/* Slide Navigation Information Layer */}
      <div className="absolute inset-0 z-10 flex flex-col justify-end p-6 sm:p-12 pointer-events-none select-none">
        <div className="max-w-xl space-y-3 sm:space-y-5">
          <div className="space-y-1">
            <div className="overflow-hidden">
              <motion.h1 
                key={`title-${currentItem.id}`}
                initial={{ opacity: 0, y: 35, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ type: "spring", stiffness: 150, damping: 18, delay: 0.15 }}
                className="text-2xl sm:text-4.5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-200 uppercase leading-tight drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]"
              >
                {currentItem.title || "Instant & Safe Top-Up"}
              </motion.h1>
            </div>
            
            <div className="overflow-hidden">
              <motion.p 
                key={`sub-${currentItem.id}`}
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ type: "spring", stiffness: 120, damping: 20, delay: 0.28 }}
                className="text-slate-300 text-xs sm:text-base leading-relaxed max-w-lg drop-shadow-[0_1px_5px_rgba(0,0,0,0.9)] font-medium"
              >
                {currentItem.subtitle || "Get the cheapest in-game currency rates with trusted 1-5 minutes delivery."}
              </motion.p>
            </div>
          </div>

          {currentItem.linkUrl && (
            <motion.div
              key={`link-${currentItem.id}`}
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 180, damping: 15, delay: 0.4 }}
              className="pt-1.5 pointer-events-auto"
            >
              <a
                href={currentItem.linkUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-black font-extrabold text-xs tracking-wider uppercase transition-all duration-300 shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_25px_rgba(6,182,212,0.6)] transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Check Details</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </motion.div>
          )}
        </div>
      </div>

      {/* Manual Navigation Controls (Arrows with Beautiful Animation & Hover Flares) */}
      {activeItems.length > 1 && (
        <>
          <button
            id="carousel-btn-prev"
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-slate-950/60 border border-white/10 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 hover:scale-110 active:scale-95 hover:bg-cyan-500 hover:text-black hover:border-cyan-400 transition-all duration-300 cursor-pointer backdrop-blur-md shadow-xl shadow-black/50"
            title="Previous Slide"
          >
            <ChevronLeft className="w-5.5 h-5.5" />
          </button>
          
          <button
            id="carousel-btn-next"
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-slate-950/60 border border-white/10 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 hover:scale-110 active:scale-95 hover:bg-cyan-500 hover:text-black hover:border-cyan-400 transition-all duration-300 cursor-pointer backdrop-blur-md shadow-xl shadow-black/50"
            title="Next Slide"
          >
            <ChevronRight className="w-5.5 h-5.5" />
          </button>
        </>
      )}

      {/* Bottom Control Rail with Bullets, Play/Pause, and Interval Progress Bar */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/5 z-20 overflow-hidden">
        {activeItems.length > 1 && (
          <div 
            className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-75 ease-linear shadow-[0_0_10px_rgba(6,182,212,0.8)]"
            style={{ width: `${progress}%` }}
          />
        )}
      </div>

      <div className="absolute bottom-5 right-6 z-20 flex items-center gap-3 bg-slate-950/80 px-3.5 py-2 rounded-full border border-white/10 backdrop-blur-md shadow-lg shadow-black/60">
        {/* Play/Pause Button */}
        {activeItems.length > 1 && (
          <button
            id="carousel-btn-playpause"
            onClick={() => setIsPlaying(!isPlaying)}
            className="text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer p-0.5 hover:scale-110 active:scale-95 duration-150"
            title={isPlaying ? "Pause Autoplay" : "Play Autoplay"}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
        )}

        {/* Indicators */}
        {activeItems.length > 1 && (
          <div className="flex items-center gap-2 border-l border-white/10 pl-2">
            {activeItems.map((_, index) => (
              <button
                key={index}
                id={`carousel-bullet-${index}`}
                onClick={() => {
                  setDirection(index > currentIndex ? 1 : -1);
                  setCurrentIndex(index);
                }}
                className={`h-2 rounded-full transition-all duration-300 cursor-pointer relative ${
                  index === currentIndex ? "w-6 bg-gradient-to-r from-cyan-400 to-cyan-300" : "w-2 bg-slate-600 hover:bg-slate-400"
                }`}
                title={`Go to Slide ${index + 1}`}
              >
                {index === currentIndex && (
                  <span className="absolute inset-0 rounded-full bg-cyan-400 blur-xs animate-ping opacity-50" />
                )}
              </button>
            ))}
          </div>
        )}

        {/* Page status index */}
        <span className="text-[10px] font-mono font-bold text-cyan-400 border-l border-white/10 pl-2 select-none">
          {currentIndex + 1}/{activeItems.length}
        </span>
      </div>
    </div>
  );
}
