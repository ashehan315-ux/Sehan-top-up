import React, { useRef } from "react";
import { Order } from "../types";
import { X, Printer, ShieldCheck, Gamepad2, Landmark, Clock, CheckCircle2, QrCode } from "lucide-react";

interface InvoiceModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function InvoiceModal({ order, isOpen, onClose }: InvoiceModalProps) {
  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    const printContent = printAreaRef.current?.innerHTML;
    const originalContent = document.body.innerHTML;

    if (printContent) {
      // Create a temporary style to handle neat single-page printing
      const style = document.createElement("style");
      style.innerHTML = `
        @media print {
          body {
            background: #ffffff !important;
            color: #000000 !important;
            font-family: 'Inter', sans-serif !important;
            margin: 0 !important;
            padding: 20px !important;
          }
          .print-hidden {
            display: none !important;
          }
          .print-card {
            background: #ffffff !important;
            border: none !important;
            box-shadow: none !important;
            color: #000000 !important;
            width: 100% !important;
            max-width: 100% !important;
          }
          .print-text-dark {
            color: #111827 !important;
          }
          .print-text-muted {
            color: #4b5563 !important;
          }
          .print-border-slate {
            border-color: #e5e7eb !important;
          }
          .print-bg-light {
            background-color: #f9fafb !important;
          }
          .print-accent {
            color: #0891b2 !important;
          }
        }
      `;
      document.head.appendChild(style);
      window.print();
      document.head.removeChild(style);
    }
  };

  // Safe dates
  const formattedDate = new Date(order.createdAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });

  const invoiceNumber = `INV-${order.id.replace("ORD-", "") || "109482"}`;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in print:p-0">
      {/* Outer Card Wrapper */}
      <div className="bg-[#0c0c14]/95 border border-white/10 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh] print:max-h-full print:bg-white print:border-none print:shadow-none print:w-full">
        
        {/* Header Options - Hidden on Print */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-[#08080f] print-hidden">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="text-xs font-black uppercase text-white tracking-widest">Transaction Invoice Ready</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="invoice-modal-print-btn"
              onClick={handlePrint}
              className="p-2 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500 hover:text-black text-cyan-400 rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
            <button
              id="invoice-modal-close-btn"
              onClick={onClose}
              className="p-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded-xl text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Invoice Area */}
        <div 
          className="p-8 overflow-y-auto space-y-6 print:overflow-visible print:p-0"
          ref={printAreaRef}
          id="invoice-print-area"
        >
          <div className="bg-[#07070c] border border-white/5 rounded-2xl p-6 md:p-8 space-y-8 relative overflow-hidden print-card print:bg-white print:border-none print:p-0">
            {/* Glowing Watermark background (Non-Printable) */}
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none print:hidden" />
            
            {/* Authentic "PAID" Stamp */}
            {order.status === "completed" && (
              <div className="absolute top-8 right-8 md:top-12 md:right-12 transform rotate-12 border-4 border-emerald-500/30 text-emerald-400 font-black uppercase tracking-widest text-[11px] sm:text-xs px-3 py-1.5 rounded-lg select-none flex flex-col items-center justify-center opacity-80 print:border-emerald-700 print:text-emerald-700">
                <span>PAID & DELIVERED</span>
                <span className="text-[8px] tracking-widest mt-0.5">SEHAN TOPUP STORE</span>
              </div>
            )}

            {/* Top Row: Brand Info & Invoice Meta */}
            <div className="flex flex-col md:flex-row justify-between gap-6 pb-6 border-b border-white/5 print-border-slate">
              <div className="space-y-2">
                <div className="text-xl font-black tracking-tighter text-white print-text-dark uppercase flex items-center gap-2">
                  <span className="text-cyan-400 print-accent">SEHAN</span>
                  <span>TOPUP</span>
                </div>
                <p className="text-xs text-slate-400 print-text-muted leading-relaxed">
                  Sehan Topup Store Ltd.<br />
                  Colombo, Sri Lanka<br />
                  Support: sehantopupstore@gmail.com<br />
                  Phone: +94 72 136 7605
                </p>
              </div>

              <div className="text-left md:text-right space-y-1">
                <span className="text-[10px] uppercase font-black tracking-widest text-cyan-400 print-accent block">Receipt Invoice</span>
                <h3 className="text-lg font-mono font-bold text-white print-text-dark">{invoiceNumber}</h3>
                <p className="text-xs text-slate-400 print-text-muted">Date: {formattedDate}</p>
                <p className="text-xs text-slate-400 print-text-muted">Status: <strong className="text-emerald-400 print-text-dark font-extrabold uppercase">SUCCESSFUL</strong></p>
              </div>
            </div>

            {/* Customer & Server Details Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-white/[0.02] border border-white/5 rounded-xl p-5 print-bg-light print-border-slate">
              <div>
                <span className="text-[9px] uppercase tracking-wider text-slate-400 print-text-muted font-bold block mb-1">Billed To</span>
                <p className="text-xs text-white print-text-dark font-extrabold">
                  {order.username || "Guest Customer"}
                </p>
                {order.userId && (
                  <p className="text-[11px] text-slate-400 print-text-muted font-mono mt-0.5">User ID: {order.userId}</p>
                )}
              </div>

              <div className="text-left sm:text-right">
                <span className="text-[9px] uppercase tracking-wider text-slate-400 print-text-muted font-bold block mb-1">Target Player Account</span>
                <p className="text-xs text-cyan-400 print-accent font-mono font-extrabold">
                  Player ID: {order.playerId}
                </p>
                {order.playerZoneId && (
                  <p className="text-[11px] text-slate-400 print-text-muted font-bold mt-0.5">Zone/Server: {order.playerZoneId}</p>
                )}
              </div>
            </div>

            {/* Itemized Transactions Table */}
            <div className="space-y-3">
              <span className="text-[9px] uppercase tracking-widest text-slate-400 print-text-muted font-black block">Bill Summary Items</span>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-white/5 text-slate-400 print-text-muted print-border-slate">
                      <th className="py-2.5 font-bold">Item Description</th>
                      <th className="py-2.5 font-bold text-center">Qty</th>
                      <th className="py-2.5 font-bold text-right">Payment Gateway</th>
                      <th className="py-2.5 font-bold text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-white/5 print-border-slate font-medium text-white print-text-dark">
                      <td className="py-4">
                        <div className="flex items-center gap-2">
                          <Gamepad2 className="w-4 h-4 text-cyan-400 print-accent shrink-0" />
                          <div>
                            <p className="font-bold">{order.gameName}</p>
                            <p className="text-[10px] text-slate-400 print-text-muted font-normal">Pack: {order.packageName}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 text-center">1</td>
                      <td className="py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Landmark className="w-3 h-3 text-slate-500" />
                          <span className="font-semibold text-xs">{order.paymentMethodName}</span>
                        </div>
                      </td>
                      <td className="py-4 text-right font-mono font-extrabold">LKR {order.price.toFixed(2)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Calculations Balance Summary Row */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 pt-2">
              {/* Mock Barcode for immersive official merchant vibes */}
              <div className="space-y-1.5 flex flex-col">
                <div className="flex h-8 w-44 gap-0.5 overflow-hidden opacity-75 print:opacity-100">
                  <div className="w-1.5 bg-white print:bg-black shrink-0" />
                  <div className="w-0.5 bg-white print:bg-black shrink-0" />
                  <div className="w-1 bg-white print:bg-black shrink-0" />
                  <div className="w-2.5 bg-white print:bg-black shrink-0" />
                  <div className="w-0.5 bg-white print:bg-black shrink-0" />
                  <div className="w-1 bg-white print:bg-black shrink-0" />
                  <div className="w-2 bg-white print:bg-black shrink-0" />
                  <div className="w-1.5 bg-white print:bg-black shrink-0" />
                  <div className="w-0.5 bg-white print:bg-black shrink-0" />
                  <div className="w-2 bg-white print:bg-black shrink-0" />
                  <div className="w-1 bg-white print:bg-black shrink-0" />
                  <div className="w-0.5 bg-white print:bg-black shrink-0" />
                  <div className="w-1.5 bg-white print:bg-black shrink-0" />
                </div>
                <span className="text-[8px] font-mono tracking-[0.3em] text-slate-500 uppercase print:text-slate-600">
                  {order.id}
                </span>
              </div>

              <div className="w-full sm:w-64 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400 print:text-slate-600">
                  <span>Subtotal:</span>
                  <span className="font-mono">LKR {order.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400 print:text-slate-600">
                  <span>Merchant Processing Fee:</span>
                  <span className="font-mono">LKR 0.00</span>
                </div>
                <div className="flex justify-between border-t border-white/10 pt-2 text-white print-text-dark font-black text-sm">
                  <span>Total Paid:</span>
                  <span className="text-cyan-400 print-accent font-mono text-base">LKR {order.price.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Payment Audit Code Reference */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-white/5 pt-6 print-border-slate text-[10px] text-slate-400 print:text-slate-600">
              <div className="space-y-1">
                <span className="font-bold text-white print-text-dark uppercase tracking-wide block">Verification Reference Info</span>
                <p className="font-mono">Txn ID: {order.transactionId || "System Auto Approved"}</p>
                {order.senderNumber && <p className="font-mono">From: {order.senderNumber}</p>}
                <p>Gateway Ref: SSL_SECURE_AUTH_{order.id.replace("ORD-", "")}</p>
              </div>
              <div className="text-left sm:text-right flex flex-col sm:items-end justify-end">
                <p className="font-bold text-white print-text-dark">Thank you for your business!</p>
                <p className="text-[9px] text-slate-500 mt-0.5">Please contact us for support regarding topup credits if they have not arrived within 5 minutes.</p>
              </div>
            </div>
          </div>

          {/* Secure Audit Tag info */}
          <div className="text-center text-[10px] text-slate-500 flex items-center justify-center gap-1.5 print:hidden">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
            <span>Digital Authenticated Receipt powered by Sehan Topup Core SSL.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
