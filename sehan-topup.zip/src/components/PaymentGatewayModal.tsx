import React, { useState, useEffect } from "react";
import { Order, PaymentMethod } from "../types";
import { Shield, Lock, CreditCard, Send, X, Landmark, Smartphone, RefreshCw, Key, Upload, Image, Trash2, AlertCircle, Check } from "lucide-react";

interface PaymentGatewayModalProps {
  order: Order;
  paymentMethod: PaymentMethod;
  onClose: () => void;
  onPaymentSuccess: (updatedOrder: Order) => void;
}

export default function PaymentGatewayModal({
  order,
  paymentMethod,
  onClose,
  onPaymentSuccess,
}: PaymentGatewayModalProps) {
  const [step, setStep] = useState<"gateway" | "processing" | "otp" | "success">("gateway");
  const [transactionId, setTransactionId] = useState("");
  const [senderNumber, setSenderNumber] = useState("");
  const [cardHolder, setCardHolder] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [error, setError] = useState("");
  const [countdown, setCountdown] = useState(180); // 3 minutes timeout

  // Receipt upload state
  const [receiptUrl, setReceiptUrl] = useState("");
  const [uploadingReceipt, setUploadingReceipt] = useState(false);
  const [receiptUploadError, setReceiptUploadError] = useState("");

  const handleReceiptUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingReceipt(true);
    setReceiptUploadError("");

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (err) => reject(err);
        reader.readAsDataURL(file);
      });

      const base64Data = await base64Promise;

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          filename: file.name,
          base64Data
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to upload image");
      }

      const { url } = await res.json();
      setReceiptUrl(url);
    } catch (err: any) {
      console.error(err);
      setReceiptUploadError(err.message || "Failed to upload receipt photo.");
    } finally {
      setUploadingReceipt(false);
    }
  };

  // Gateway Timer Countdown
  useEffect(() => {
    if (countdown <= 0) {
      setError("Payment window expired. Please try checkout again.");
      return;
    }
    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [countdown]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  const handleWalletBankSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (paymentMethod.type === "wallet" && !senderNumber.trim()) {
      setError("Please provide the account number you sent the funds from.");
      return;
    }

    if (!transactionId.trim()) {
      setError("Please enter the unique Transaction ID from your transaction receipt.");
      return;
    }

    setStep("processing");

    // Send payment verification proof to the server
    try {
      const response = await fetch(`/api/orders/${order.id}/verify-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transactionId: transactionId.trim(),
          senderNumber: senderNumber.trim() || undefined,
          receiptUrl: receiptUrl || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to verify transaction ID.");
      }

      const updatedOrder = await response.json();
      setTimeout(() => {
        setStep("success");
        onPaymentSuccess(updatedOrder);
      }, 1500);
    } catch (err: any) {
      setError(err.message || "Something went wrong.");
      setStep("gateway");
    }
  };

  const handleCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!cardHolder.trim() || cardNumber.length < 16 || cardExpiry.length < 5 || cardCvv.length < 3) {
      setError("Please fill out all card details correctly.");
      return;
    }

    setStep("processing");

    // Simulate contacting payment processor
    setTimeout(() => {
      setStep("otp");
    }, 2000);
  };

  const handleOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (otpCode !== "1234" && otpCode !== "123456") {
      // Allow demo code '1234'
      setError("Invalid OTP code. For demo purposes, please enter '1234'.");
      return;
    }

    setStep("processing");

    try {
      const cardLast4 = cardNumber.slice(-4);
      const response = await fetch(`/api/orders/${order.id}/verify-payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transactionId: `VISA-CARD-${Math.floor(10000000 + Math.random() * 90000000)}`,
          cardLast4,
        }),
      });

      if (!response.ok) {
        throw new Error("Card processing failed on server.");
      }

      const updatedOrder = await response.json();
      setTimeout(() => {
        setStep("success");
        onPaymentSuccess(updatedOrder);
      }, 1500);
    } catch (err: any) {
      setError(err.message || "Failed to finalize card payment.");
      setStep("otp");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#04040a]/95 backdrop-blur-md" id="gateway-modal">
      <div className="relative w-full max-w-md bg-[#0c0c14] border border-white/10 rounded-2xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header bar */}
        <div className="p-4 bg-white/[0.02] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">Sehan Topup Secure Checkout</span>
          </div>
          {step !== "processing" && (
            <button id="close-modal-btn" onClick={onClose} className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Modal body */}
        <div className="p-6">
          {step === "gateway" && (
            <div id="step-gateway-content">
              {/* Checkout details block */}
              <div className="flex justify-between items-center p-4 bg-[#04040a] border border-white/10 rounded-xl mb-5">
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Order ID</p>
                  <p className="text-xs font-mono font-bold text-white mt-0.5">{order.id}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Price Payable</p>
                  <p className="text-sm font-black text-cyan-400 mt-0.5">LKR {order.price.toFixed(2)}</p>
                </div>
                <div className="text-right border-l border-white/10 pl-3">
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Timer</p>
                  <p className="text-xs font-bold text-amber-400 mt-0.5">{formatTime(countdown)}</p>
                </div>
              </div>

              {/* CARD GATEWAY OPTION */}
              {paymentMethod.type === "card" && (
                <form onSubmit={handleCardSubmit} className="space-y-4" id="card-form">
                  <div className="p-4 bg-indigo-950/20 rounded-xl border border-indigo-500/10 flex items-center gap-3">
                    <CreditCard className="w-6 h-6 text-indigo-400" />
                    <div>
                      <h4 className="text-xs font-bold text-white">Credit / Debit Card Secure Gateway</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">Supports Visa, Mastercard, AMEX</p>
                    </div>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">Cardholder Name</label>
                      <input
                        id="card-holder-input"
                        type="text"
                        placeholder="e.g. John Doe"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">Card Number</label>
                      <input
                        id="card-number-input"
                        type="text"
                        maxLength={16}
                        placeholder="4111 2222 3333 4444"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, ""))}
                        className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white font-mono"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">Expiry (MM/YY)</label>
                        <input
                          id="card-expiry-input"
                          type="text"
                          maxLength={5}
                          placeholder="12/28"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white text-center font-mono"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">CVV / CVC</label>
                        <input
                          id="card-cvv-input"
                          type="password"
                          maxLength={3}
                          placeholder="***"
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ""))}
                          className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white text-center font-mono"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {error && <p className="text-[11px] text-red-400 font-medium">{error}</p>}

                  <button
                    id="pay-card-btn"
                    type="submit"
                    className="w-full py-3.5 mt-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95 transition-all cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Pay LKR {order.price.toFixed(2)} Securely</span>
                  </button>
                </form>
              )}

              {/* MOBILE WALLET / QR / BANK OPTION */}
              {paymentMethod.type !== "card" && (
                <form onSubmit={handleWalletBankSubmit} className="space-y-4" id="wallet-bank-form">
                  <div className="p-4 bg-cyan-950/20 rounded-xl border border-cyan-500/10 space-y-2 text-xs text-slate-300">
                    <div className="flex items-center gap-2 font-bold text-white uppercase tracking-wider">
                      {paymentMethod.type === "wallet" && <Smartphone className="w-4 h-4 text-cyan-400" />}
                      {paymentMethod.type === "bank" && <Landmark className="w-4 h-4 text-cyan-400" />}
                      {paymentMethod.type === "qr" && <Send className="w-4 h-4 text-cyan-400" />}
                      <span>Payment Instructions:</span>
                    </div>
                    {paymentMethod.instructions ? (
                      <p className="leading-relaxed font-medium">{paymentMethod.instructions}</p>
                    ) : (
                      <p className="leading-relaxed">Please make a transfer of exactly <strong className="text-white">LKR {order.price.toFixed(2)}</strong> to our official store credentials below.</p>
                    )}

                    {(paymentMethod.accountNumber || paymentMethod.accountName) && (
                      <div className="mt-3 p-3 bg-[#04040a] border border-white/10 rounded-lg space-y-1 font-mono text-[11px]">
                        {paymentMethod.accountNumber && (
                          <div className="flex justify-between">
                            <span className="text-slate-500">Account No:</span>
                            <span className="text-white font-bold tracking-wider select-all">{paymentMethod.accountNumber}</span>
                          </div>
                        )}
                        {paymentMethod.accountName && (
                          <div className="flex justify-between">
                            <span className="text-slate-500">Holder:</span>
                            <span className="text-slate-300 font-bold">{paymentMethod.accountName}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {paymentMethod.type === "qr" && (
                    <div className="flex flex-col items-center justify-center py-2" id="qr-display">
                      <div className="p-2.5 bg-white rounded-xl shadow-lg border border-gray-300">
                        {/* Elegant generated mock QR code using inline canvas SVG */}
                        <svg className="w-32 h-32 text-gray-900" viewBox="0 0 100 100">
                          <rect width="100" height="100" fill="white" />
                          <path d="M10,10 h20 v20 h-20 z M15,15 h10 v10 h-10 z" fill="currentColor" />
                          <path d="M70,10 h20 v20 h-20 z M75,15 h10 v10 h-10 z" fill="currentColor" />
                          <path d="M10,70 h20 v20 h-20 z M15,75 h10 v10 h-10 z" fill="currentColor" />
                          <path d="M40,10 h10 v10 h-10 z M55,10 h10 v10 h-10 z M45,25 h15 v5 h-15 z" fill="currentColor" />
                          <path d="M10,40 h15 v10 h-15 z M35,40 h15 v5 h-15 z M60,40 h10 v20 h-10 z M80,40 h10 v10 h-10 z" fill="currentColor" />
                          <path d="M40,55 h10 v25 h-10 z M15,60 h5 v5 h-5 z M50,70 h15 v5 h-15 z M75,70 h15 v5 h-15 z" fill="currentColor" />
                          <path d="M70,80 h10 v10 h-10 z M85,85 h10 v5 h-10 z M45,85 h15 v5 h-15 z" fill="currentColor" />
                        </svg>
                      </div>
                      <p className="text-[9px] text-slate-500 mt-1.5 font-bold uppercase tracking-wider">Scan QR using mobile app</p>
                    </div>
                  )}

                  <div className="space-y-3.5 text-xs">
                    {paymentMethod.type === "wallet" && (
                      <div>
                        <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">Your Mobile Wallet Number</label>
                        <input
                          id="sender-number-input"
                          type="text"
                          placeholder="e.g. +880 1712 345678"
                          value={senderNumber}
                          onChange={(e) => setSenderNumber(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white"
                          required
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">Transaction ID / Reference Number</label>
                      <input
                        id="transaction-id-input"
                        type="text"
                        placeholder="e.g. TRX82940284"
                        value={transactionId}
                        onChange={(e) => setTransactionId(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white font-mono"
                        required
                      />
                      <p className="text-[10px] text-slate-500 mt-1">Copy and paste the transaction transaction id from your SMS receipt.</p>
                    </div>

                    {/* Optional Receipt Upload */}
                    <div>
                      <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider flex justify-between items-center">
                        <span>Upload Payment Receipt (Optional)</span>
                        <span className="text-[10px] text-slate-500 font-medium normal-case">නැතත් කමක් නැත / Optional</span>
                      </label>
                      
                      <div className="bg-white/5 border border-dashed border-white/10 rounded-lg p-3 text-center space-y-2">
                        {receiptUrl ? (
                          <div className="space-y-2">
                            <div className="relative inline-block">
                              <img referrerPolicy="no-referrer" src={receiptUrl} alt="Receipt Proof" className="max-h-32 mx-auto rounded-lg object-contain border border-white/10" />
                              <button
                                type="button"
                                onClick={() => setReceiptUrl("")}
                                className="absolute -top-1.5 -right-1.5 bg-red-500 hover:bg-red-600 text-white p-1 rounded-full shadow-lg transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <p className="text-[10px] text-emerald-400 font-bold flex items-center justify-center gap-1">
                              <Check className="w-3.5 h-3.5" /> Receipt uploaded successfully!
                            </p>
                          </div>
                        ) : (
                          <label className="block cursor-pointer py-1">
                            <div className="flex flex-col items-center gap-1.5 text-slate-400 hover:text-white transition-colors">
                              {uploadingReceipt ? (
                                <>
                                  <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
                                  <span className="text-xs font-semibold">Uploading proof...</span>
                                </>
                              ) : (
                                <>
                                  <Upload className="w-6 h-6 text-cyan-400" />
                                  <span className="text-xs font-semibold">Click to select receipt image</span>
                                  <span className="text-[9px] text-slate-500 font-medium">Supports PNG, JPG, JPEG</span>
                                </>
                              )}
                            </div>
                            <input
                              type="file"
                              accept="image/*"
                              disabled={uploadingReceipt}
                              onChange={handleReceiptUpload}
                              className="hidden"
                            />
                          </label>
                        )}
                      </div>
                      {receiptUploadError && (
                        <p className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 shrink-0" />
                          <span>{receiptUploadError}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  {error && <p className="text-[11px] text-red-400 font-medium">{error}</p>}

                  <button
                    id="submit-payment-proof-btn"
                    type="submit"
                    className="w-full py-3.5 mt-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95 transition-all cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Confirm Top-Up Checkout</span>
                  </button>
                </form>
              )}

              <div className="flex items-center justify-center gap-2 mt-5 text-[10px] text-slate-500">
                <Lock className="w-3 h-3 text-cyan-400" />
                <span>256-bit AES SSL Security Certificate</span>
              </div>
            </div>
          )}

          {step === "processing" && (
            <div className="flex flex-col items-center justify-center py-10 space-y-4" id="step-processing-content">
              <RefreshCw className="w-10 h-10 text-cyan-400 animate-spin" />
              <div className="text-center">
                <h4 className="font-bold text-white text-sm">Processing Secure Transaction</h4>
                <p className="text-xs text-slate-400 mt-1">Verifying encrypted payment token details...</p>
              </div>
            </div>
          )}

          {step === "otp" && (
            <form onSubmit={handleOtpVerify} className="space-y-4" id="otp-form">
              <div className="p-4 bg-amber-950/20 rounded-xl border border-amber-500/10 flex items-center gap-3">
                <Key className="w-6 h-6 text-amber-400" />
                <div>
                  <h4 className="text-xs font-bold text-white">3D Secure Validation</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">Enter the security code texted to your phone.</p>
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-bold mb-1 uppercase tracking-wider">One-Time Password (OTP)</label>
                  <input
                    id="otp-code-input"
                    type="text"
                    placeholder="Enter OTP (Use '1234' for Demo)"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500/50 transition-colors text-white text-center font-bold font-mono tracking-widest text-lg"
                    required
                  />
                  <p className="text-[10px] text-slate-500 mt-1 text-center font-semibold">For easy simulation testing, type <strong className="text-white">1234</strong> as the verification code.</p>
                </div>
              </div>

              {error && <p className="text-[11px] text-red-400 font-medium text-center">{error}</p>}

              <button
                id="verify-otp-btn"
                type="submit"
                className="w-full py-3.5 mt-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg active:scale-95 transition-all cursor-pointer"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Verify OTP & Authorize Payment</span>
              </button>
            </form>
          )}

          {step === "success" && (
            <div className="flex flex-col items-center justify-center py-8 space-y-4 text-center animate-fade-in" id="step-success-content">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Shield className="w-6 h-6 stroke-[2.5]" />
              </div>
              <div>
                <h4 className="font-black text-white text-base">Payment Authorized</h4>
                <p className="text-xs text-slate-400 mt-1">Proof of payment registered successfully.</p>
                <p className="text-[10.5px] text-cyan-400 font-bold mt-1 uppercase tracking-widest">Opening Order Status Tracker...</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
