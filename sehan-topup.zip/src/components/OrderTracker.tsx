import React, { useState, useEffect, useRef } from "react";
import { Order } from "../types";
import { Search, Clock, CheckCircle2, RotateCw, AlertTriangle, Printer, Copy, Check, ShieldCheck, Landmark, Volume2 } from "lucide-react";
import InvoiceModal from "./InvoiceModal";

interface OrderTrackerProps {
  initialOrderId?: string;
  onSelectOrder?: (order: Order) => void;
}

export default function OrderTracker({ initialOrderId, onSelectOrder }: OrderTrackerProps) {
  const [searchQuery, setSearchQuery] = useState(initialOrderId || "");
  const [loading, setLoading] = useState(false);
  const [ordersList, setOrdersList] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);

  // Poll active selected order state if it's pending/processing
  useEffect(() => {
    if (!selectedOrder) return;
    
    const isFinished = ["completed", "failed"].includes(selectedOrder.status);
    if (isFinished) return;

    const interval = setInterval(async () => {
      try {
        const response = await fetch(`/api/orders/${selectedOrder.id}`);
        if (response.ok) {
          const freshOrder = await response.json();
          setSelectedOrder(freshOrder);
          if (onSelectOrder) onSelectOrder(freshOrder);
        }
      } catch (err) {
        console.error("Error polling order status:", err);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [selectedOrder, onSelectOrder]);

  // Web Audio synthesizer for a pristine, premium sci-fi success chime
  const playSuccessChime = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;

      const ctx = new AudioContextClass();
      
      // Resume if suspended by browser auto-play policy
      if (ctx.state === "suspended") {
        ctx.resume();
      }

      const now = ctx.currentTime;
      
      const playTone = (freq: number, startTime: number, duration: number, type: "sine" | "triangle" = "sine") => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        osc.type = type;
        osc.frequency.setValueAtTime(freq, startTime);
        
        // Beautiful volume envelope (fast attack, sweet exponential decay)
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.18, startTime + 0.04);
        gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
        
        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.start(startTime);
        osc.stop(startTime + duration);
      };

      // Play a delightful, ascending pentatonic scale chime (C5 -> E5 -> G5 -> C6)
      playTone(523.25, now, 0.8, "sine");       // C5
      playTone(659.25, now + 0.08, 0.8, "sine"); // E5
      playTone(783.99, now + 0.16, 1.0, "sine"); // G5
      playTone(1046.50, now + 0.24, 1.2, "sine"); // C6 (sweet crystal ring)

      // Warm background resonance synth tone
      const padOsc = ctx.createOscillator();
      const padGain = ctx.createGain();
      padOsc.type = "triangle";
      padOsc.frequency.setValueAtTime(261.63, now); // C4 base
      padGain.gain.setValueAtTime(0, now);
      padGain.gain.linearRampToValueAtTime(0.06, now + 0.1);
      padGain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);
      padOsc.connect(padGain);
      padGain.connect(ctx.destination);
      padOsc.start(now);
      padOsc.stop(now + 1.5);

    } catch (error) {
      console.warn("Audible notification skipped due to browser constraints:", error);
    }
  };

  // Play sound when order status transitions to 'completed'
  const prevStatusRef = useRef<string | null>(null);

  useEffect(() => {
    if (selectedOrder) {
      const currentStatus = selectedOrder.status;
      const prevStatus = prevStatusRef.current;

      // Only trigger if it transitions from a pending status to completed while actively being tracked
      if (currentStatus === "completed" && prevStatus !== "completed" && prevStatus !== null) {
        playSuccessChime();
      }
      prevStatusRef.current = currentStatus;
    } else {
      prevStatusRef.current = null;
    }
  }, [selectedOrder?.id, selectedOrder?.status]);

  // Initial trigger if ID is passed
  useEffect(() => {
    if (initialOrderId) {
      setSearchQuery(initialOrderId);
      handleSearch(initialOrderId);
    }
  }, [initialOrderId]);

  const handleSearch = async (queryToSearch: string) => {
    const query = queryToSearch || searchQuery;
    if (!query.trim()) {
      setError("Please input an Order ID, Player ID, or Transaction Code.");
      return;
    }

    setLoading(true);
    setError("");
    setSelectedOrder(null);

    try {
      const response = await fetch(`/api/orders-lookup?query=${encodeURIComponent(query.trim())}`);
      if (!response.ok) throw new Error("Order search failed.");
      
      const results: Order[] = await response.json();
      setOrdersList(results);

      if (results.length === 1) {
        setSelectedOrder(results[0]);
        if (onSelectOrder) onSelectOrder(results[0]);
      } else if (results.length === 0) {
        setError("No orders found matching your search term.");
      }
    } catch (err) {
      setError("Failed to retrieve order tracking. Check connection.");
    } finally {
      setLoading(false);
    }
  };

  const triggerCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(label);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const printReceipt = () => {
    window.print();
  };

  const getStatusBadgeStyles = (status: Order["status"]) => {
    switch (status) {
      case "awaiting_payment":
        return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case "verifying":
        return "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20";
      case "processing":
        return "bg-purple-500/10 text-purple-400 border border-purple-500/20";
      case "completed":
        return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
      case "failed":
        return "bg-red-500/10 text-red-400 border border-red-500/20";
    }
  };

  const getStepStyles = (orderStatus: Order["status"], stepIndex: number) => {
    // Step Indexes: 1=Placed, 2=Verifying, 3=Processing, 4=Completed
    const statusMap: Record<Order["status"], number> = {
      awaiting_payment: 1,
      verifying: 2,
      processing: 3,
      completed: 4,
      failed: 4,
    };

    const currentStep = statusMap[orderStatus];

    if (orderStatus === "failed" && stepIndex === 4) {
      return {
        circle: "bg-red-500/20 text-red-400 border-red-500",
        line: "bg-white/5",
        label: "text-red-400",
      };
    }

    if (stepIndex < currentStep) {
      return {
        circle: "bg-cyan-500 text-black border-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.4)]",
        line: "bg-cyan-500",
        label: "text-cyan-400",
      };
    } else if (stepIndex === currentStep) {
      return {
        circle: "bg-[#04040a] text-cyan-400 border-cyan-500 animate-pulse shadow-[0_0_10px_rgba(6,182,212,0.3)]",
        line: "bg-white/5",
        label: "text-white font-bold",
      };
    } else {
      return {
        circle: "bg-white/5 text-slate-600 border-white/10",
        line: "bg-white/5",
        label: "text-slate-500",
      };
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto" id="order-tracker-root">
      {/* Search Console */}
      <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md">
        <h3 className="text-base font-bold text-white mb-2 uppercase tracking-wider">Track Game Top-Up Order</h3>
        <p className="text-xs text-slate-400 mb-4">Enter your Order Reference Number (e.g., DAN-123456) or your Game Player/Character ID to check real-time status.</p>
        
        <form onSubmit={(e) => { e.preventDefault(); handleSearch(""); }} className="flex gap-2">
          <div className="relative flex-1">
            <input
              id="tracker-search-input"
              type="text"
              placeholder="Search by Order ID, Player ID, or Transaction Code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500/50 transition-all font-mono"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
          </div>
          <button
            id="tracker-search-btn"
            type="submit"
            disabled={loading}
            className="px-6 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.3)]"
          >
            {loading ? <RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>Track</span>
          </button>
        </form>

        {error && (
          <p className="text-xs text-red-400 mt-3 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>{error}</span>
          </p>
        )}
      </div>

      {/* Multiple results matching selection */}
      {ordersList.length > 1 && !selectedOrder && (
        <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md space-y-3" id="tracker-multi-matches">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Multiple Matching Transactions</h4>
          <div className="space-y-2">
            {ordersList.map((o) => (
              <button
                key={o.id}
                id={`match-select-${o.id}`}
                onClick={() => { setSelectedOrder(o); if (onSelectOrder) onSelectOrder(o); }}
                className="w-full p-4 rounded-xl bg-white/5 border border-white/10 hover:border-cyan-500/50 hover:bg-white/[0.08] flex flex-col sm:flex-row sm:items-center justify-between text-left gap-3 transition-all cursor-pointer"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-bold text-white">{o.id}</span>
                    <span className="text-[10px] text-slate-400 font-medium">({o.gameName})</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">Game ID: <strong className="text-white font-mono">{o.playerId}</strong>{o.playerZoneId ? ` | Game Name: ${o.playerZoneId}` : ""} • {o.packageName}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${getStatusBadgeStyles(o.status)}`}>
                    {o.status.replace("_", " ")}
                  </span>
                  <span className="text-xs text-slate-500">{new Date(o.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Single Active Tracking Display */}
      {selectedOrder && (
        <div className="p-6 sm:p-8 rounded-2xl bg-white/[0.03] border border-white/10 space-y-8 shadow-xl backdrop-blur-md print:bg-white print:text-slate-900 print:border-none print:shadow-none" id="active-tracker-card">
          {/* Tracker summary header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-6 print:border-slate-300">
            <div>
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-bold uppercase text-cyan-400 tracking-widest print:text-cyan-700">Live Top-Up Progress</span>
                {["completed", "failed"].includes(selectedOrder.status) ? null : (
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <h2 className="text-xl font-black text-white print:text-slate-900 font-mono tracking-tight">{selectedOrder.id}</h2>
                <button
                  id="copy-order-id-btn"
                  onClick={() => triggerCopy(selectedOrder.id, "orderId")}
                  className="p-1 rounded text-slate-500 hover:text-white hover:bg-white/5 transition-colors print:hidden cursor-pointer"
                >
                  {copiedId === "orderId" ? <Check className="w-3.5 h-3.5 text-cyan-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 print:text-slate-500">Placed on {new Date(selectedOrder.createdAt).toLocaleString()}</p>
            </div>

            <div className="flex items-center gap-3 print:hidden">
              <button
                id="test-chime-sound-btn"
                onClick={playSuccessChime}
                className="p-2.5 rounded-xl border border-white/10 hover:border-cyan-500/50 hover:bg-white/[0.08] text-slate-400 hover:text-cyan-400 transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer"
                title="Test status completion alert sound"
              >
                <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
                <span className="hidden sm:inline">Test Sound</span>
              </button>
              <button
                id="print-invoice-btn"
                onClick={() => setIsInvoiceOpen(true)}
                className="p-2.5 rounded-xl border border-white/10 hover:border-cyan-500/50 hover:bg-white/[0.08] text-slate-200 transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Save Invoice</span>
              </button>
              <span className={`text-[11px] px-3 py-1 rounded-full font-bold uppercase tracking-wider border ${getStatusBadgeStyles(selectedOrder.status)}`}>
                {selectedOrder.status.replace("_", " ")}
              </span>
            </div>
          </div>

          {/* Stepper block */}
          <div className="py-6 border-b border-white/5 pb-8 print:hidden" id="visual-stepper">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-6 relative">
              {/* Stepper Lines (background connectors) */}
              <div className="absolute left-[23px] sm:left-12 sm:right-12 top-6 bottom-6 sm:bottom-auto sm:top-6 h-auto sm:h-[2px] w-[2px] sm:w-auto bg-white/5 -z-10" />

              {/* Step 1: Placed */}
              <div className="flex sm:flex-col items-center gap-4 sm:gap-2.5 text-center flex-1 w-full sm:w-auto">
                <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center font-black text-sm transition-all z-10 ${getStepStyles(selectedOrder.status, 1).circle}`}>
                  01
                </div>
                <div className="text-left sm:text-center">
                  <p className={`text-xs ${getStepStyles(selectedOrder.status, 1).label}`}>Order Placed</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Credited to system</p>
                </div>
              </div>

              {/* Step 2: Verification */}
              <div className="flex sm:flex-col items-center gap-4 sm:gap-2.5 text-center flex-1 w-full sm:w-auto">
                <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center font-black text-sm transition-all z-10 ${getStepStyles(selectedOrder.status, 2).circle}`}>
                  02
                </div>
                <div className="text-left sm:text-center">
                  <p className={`text-xs ${getStepStyles(selectedOrder.status, 2).label}`}>Verifying Slip</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Confirming payment proof</p>
                </div>
              </div>

              {/* Step 3: Processing */}
              <div className="flex sm:flex-col items-center gap-4 sm:gap-2.5 text-center flex-1 w-full sm:w-auto">
                <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center font-black text-sm transition-all z-10 ${getStepStyles(selectedOrder.status, 3).circle}`}>
                  03
                </div>
                <div className="text-left sm:text-center">
                  <p className={`text-xs ${getStepStyles(selectedOrder.status, 3).label}`}>Crediting Coins</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Injecting game packages</p>
                </div>
              </div>

              {/* Step 4: Completed */}
              <div className="flex sm:flex-col items-center gap-4 sm:gap-2.5 text-center flex-1 w-full sm:w-auto">
                <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center font-black text-sm transition-all z-10 ${getStepStyles(selectedOrder.status, 4).circle}`}>
                  {selectedOrder.status === "completed" ? "✓" : selectedOrder.status === "failed" ? "✕" : "04"}
                </div>
                <div className="text-left sm:text-center">
                  <p className={`text-xs ${getStepStyles(selectedOrder.status, 4).label}`}>
                    {selectedOrder.status === "failed" ? "Failed" : "Delivered"}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Success receipt issued</p>
                </div>
              </div>
            </div>
          </div>

          {/* Stepper Status Explainer Banner */}
          {selectedOrder.status === "awaiting_payment" && (
            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3 text-xs text-amber-400 print:hidden">
              <Clock className="w-5 h-5 shrink-0" />
              <div>
                <p className="font-bold">Awaiting Payment Verification</p>
                <p className="text-slate-300 mt-0.5">Please pay via your chosen gateway. If you have already paid, ensure you submit your Transaction ID via the payment popup.</p>
              </div>
            </div>
          )}

          {selectedOrder.status === "verifying" && (
            <div className="p-4 bg-cyan-500/10 border border-cyan-500/20 rounded-xl flex items-start gap-3 text-xs text-cyan-400 print:hidden">
              <Clock className="w-5 h-5 shrink-0 animate-spin" />
              <div>
                <p className="font-bold">Verifying Payment Slip</p>
                <p className="text-slate-300 mt-0.5">Our secure verification bot is validating your reference code: <strong className="font-mono text-white">{selectedOrder.transactionId}</strong>. This takes about 10-15 seconds.</p>
              </div>
            </div>
          )}

          {selectedOrder.status === "processing" && (
            <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl flex items-start gap-3 text-xs text-indigo-400 print:hidden">
              <Clock className="w-5 h-5 shrink-0" />
              <div>
                <p className="font-bold">Injecting Game Credits</p>
                <p className="text-slate-300 mt-0.5">Payment successfully approved! Our instant API integration is currently pushing {selectedOrder.packageName} to character account <strong className="text-white">{selectedOrder.playerId}</strong>.</p>
              </div>
            </div>
          )}

          {selectedOrder.status === "completed" && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-start gap-3 text-xs text-emerald-400 print:hidden">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <div className="flex-1">
                <p className="font-bold">Top-Up Completed successfully!</p>
                <p className="text-slate-300 mt-0.5">Your credits have been delivered to your in-game account. Thank you for using Sehan Topup! Please view or download your official digital receipt below.</p>
                <button
                  id="view-success-invoice-btn"
                  onClick={() => setIsInvoiceOpen(true)}
                  className="mt-3 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/25 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>View Official Invoice / Receipt</span>
                </button>
              </div>
            </div>
          )}

          {/* Detailed Specifications Invoice Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
            {/* Left Block: Product specifications */}
            <div className="space-y-4">
              <h3 className="font-bold text-white print:text-slate-900 uppercase tracking-widest text-[10px] text-slate-400">Order Summary</h3>
              <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-3 print:bg-white print:border-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Game:</span>
                  <span className="font-bold text-white print:text-slate-900">{selectedOrder.gameName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Package:</span>
                  <span className="font-bold text-white print:text-slate-900">{selectedOrder.packageName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Game ID:</span>
                  <span className="font-mono font-bold text-white print:text-slate-900">{selectedOrder.playerId}</span>
                </div>
                {selectedOrder.playerZoneId && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Game Name:</span>
                    <span className="font-bold text-white print:text-slate-900">{selectedOrder.playerZoneId}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-white/5 pt-3 print:border-slate-300">
                  <span className="text-slate-400">Amount Paid:</span>
                  <span className="font-extrabold text-cyan-400 print:text-slate-900 text-sm">LKR {selectedOrder.price.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Right Block: Transaction receipts */}
            <div className="space-y-4">
              <h3 className="font-bold text-white print:text-slate-900 uppercase tracking-widest text-[10px] text-slate-400">Transaction Receipts</h3>
              <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-3 print:bg-white print:border-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Payment Gateway:</span>
                  <span className="font-bold text-white print:text-slate-900">{selectedOrder.paymentMethodName}</span>
                </div>
                {selectedOrder.senderNumber && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Sender Wallet:</span>
                    <span className="font-mono text-slate-300 print:text-slate-800">{selectedOrder.senderNumber}</span>
                  </div>
                )}
                {selectedOrder.cardLast4 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Card last 4:</span>
                    <span className="font-mono text-slate-300 print:text-slate-800">**** **** **** {selectedOrder.cardLast4}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-400">Transaction ID:</span>
                  <span className="font-mono text-slate-300 print:text-slate-800">{selectedOrder.transactionId || "Pending Input"}</span>
                </div>
                {selectedOrder.receiptUrl && (
                  <div className="flex justify-between items-center pt-2 border-t border-white/5 print:hidden">
                    <span className="text-slate-400">Payment Receipt:</span>
                    <a
                      href={selectedOrder.receiptUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-cyan-400 hover:text-cyan-300 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5 shrink-0" />
                      <span>View Uploaded Copy</span>
                    </a>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-400">Estimated Delivery:</span>
                  <span className="text-cyan-400 font-bold print:text-slate-900">{selectedOrder.estimatedDelivery || "3-5 Min"}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Secure Watermark */}
          <div className="text-center pt-4 border-t border-white/5 text-[10px] text-slate-500 flex items-center justify-center gap-1.5 print:text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Digital Authenticated Receipt powered by Sehan Topup SSL Core. Game Topups are processed legally.</span>
          </div>
        </div>
      )}

      {/* Beautiful High-Fidelity Printable Invoice Modal */}
      <InvoiceModal
        order={selectedOrder}
        isOpen={isInvoiceOpen}
        onClose={() => setIsInvoiceOpen(false)}
      />
    </div>
  );
}
