import React, { useState, useEffect } from "react";
import { Order, OrderStatus } from "../types";
import { Hammer, CheckCircle, RotateCw, AlertTriangle, ShieldCheck, Cpu } from "lucide-react";

interface AdminSimulationPanelProps {
  activeOrder: Order | null;
  onOrderUpdated: (updatedOrder: Order) => void;
}

export default function AdminSimulationPanel({ activeOrder, onOrderUpdated }: AdminSimulationPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const updateStatus = async (status: OrderStatus) => {
    if (!activeOrder) return;
    setLoading(true);
    setError("");

    try {
      const response = await fetch(`/api/orders/${activeOrder.id}/update-status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (!response.ok) throw new Error("Failed to update status on server.");

      const updated = await response.json();
      onOrderUpdated(updated);
    } catch (err: any) {
      setError(err.message || "Failed to update state.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 print:hidden" id="admin-simulation-panel">
      {/* Trigger floating button */}
      <button
        id="admin-panel-toggle"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-[#0c0c14]/90 backdrop-blur border border-white/15 hover:border-cyan-500 hover:text-cyan-400 text-slate-200 text-xs font-bold shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer"
      >
        <Hammer className="w-4 h-4 text-cyan-400" />
        <span>Admin Sandbox</span>
        {activeOrder && activeOrder.status !== "completed" && activeOrder.status !== "failed" && (
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
        )}
      </button>

      {/* Admin Panel Body */}
      {isOpen && (
        <div className="absolute bottom-14 right-0 w-80 p-5 rounded-2xl bg-[#0c0c14]/95 backdrop-blur-md border border-white/10 shadow-2xl text-slate-200 animate-fade-in space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-xs uppercase tracking-wider">
              <Cpu className="w-4 h-4" />
              <span>Simulation Console</span>
            </div>
            <button
              id="admin-panel-close"
              onClick={() => setIsOpen(false)}
              className="text-xs text-slate-500 hover:text-white cursor-pointer"
            >
              Close
            </button>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            Use this dashboard to test how the transaction tracker responds in real-time. You can manually approve, decline, or process the active order below!
          </p>

          {activeOrder ? (
            <div className="p-3 bg-[#04040a] border border-white/10 rounded-xl space-y-2.5 text-xs text-left" id="admin-active-order-details">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Active ID</span>
                <span className="font-mono font-bold text-indigo-300">{activeOrder.id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Current Status</span>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase bg-white/5 border border-white/10 text-cyan-400 tracking-wider">
                  {activeOrder.status.replace("_", " ")}
                </span>
              </div>

              {/* Status Action Buttons */}
              <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-white/5">
                <button
                  id="admin-btn-verifying"
                  onClick={() => updateStatus("verifying")}
                  disabled={loading}
                  className="px-2.5 py-1.5 rounded-lg bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-400 border border-yellow-500/20 font-bold text-[10px] transition-all cursor-pointer"
                >
                  Verify Payment
                </button>
                <button
                  id="admin-btn-processing"
                  onClick={() => updateStatus("processing")}
                  disabled={loading}
                  className="px-2.5 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/20 font-bold text-[10px] transition-all cursor-pointer"
                >
                  Process Top-Up
                </button>
                <button
                  id="admin-btn-completed"
                  onClick={() => updateStatus("completed")}
                  disabled={loading}
                  className="px-2.5 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-bold text-[10px] transition-all col-span-2 cursor-pointer flex items-center justify-center gap-1"
                >
                  <CheckCircle className="w-3 h-3" />
                  <span>Approve & Deliver</span>
                </button>
                <button
                  id="admin-btn-failed"
                  onClick={() => updateStatus("failed")}
                  disabled={loading}
                  className="px-2.5 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-bold text-[10px] transition-all col-span-2 cursor-pointer"
                >
                  Fail / Cancel Order
                </button>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-[#04040a] border border-white/10 rounded-xl text-center text-xs text-slate-500">
              No active order selected. Place a top-up order first to simulate real-time operations!
            </div>
          )}

          {error && (
            <div className="p-2 bg-red-500/10 border border-red-500/20 rounded-lg text-[10px] text-red-400 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex items-center gap-1.5 justify-center text-[9px] text-slate-600 font-bold border-t border-white/5 pt-3">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-500" />
            <span>Developer Sandbox Environment</span>
          </div>
        </div>
      )}
    </div>
  );
}
