import React, { useState } from "react";
import { GameInfo, GamePackage, PaymentMethod } from "../types";
import { User, Layers, Check, Shield, HelpCircle, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GameDetailsProps {
  game: GameInfo;
  paymentMethods: PaymentMethod[];
  onInitiateCheckout: (data: {
    playerId: string;
    playerZoneId?: string;
    selectedPackage: GamePackage;
    selectedPayment: PaymentMethod;
  }) => void;
  currentUser?: any;
}

export default function GameDetails({ game, paymentMethods, onInitiateCheckout, currentUser }: GameDetailsProps) {
  const [playerId, setPlayerId] = useState("");
  const [playerZoneId, setPlayerZoneId] = useState("");
  const [selectedPackage, setSelectedPackage] = useState<GamePackage | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | null>(null);
  const [showIdHelp, setShowIdHelp] = useState(false);
  const [error, setError] = useState("");

  const userWalletMethod: PaymentMethod = {
    id: "user_wallet",
    name: "Sehan Personal Wallet",
    type: "wallet",
    logo: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=100&auto=format&fit=crop&q=80",
    instructions: "Pay instantly using your Sehan Personal Wallet. The required amount will be automatically deducted from your account balance. No receipt upload required!",
    feePercentage: 0,
    accountNumber: `Your Balance: LKR ${(currentUser?.walletBalance || 0).toFixed(2)}`
  };

  const displayedPaymentMethods = currentUser
    ? [userWalletMethod, ...paymentMethods]
    : paymentMethods;

  const handleCheckoutClick = () => {
    setError("");
    if (!playerId.trim()) {
      setError("Please enter a valid Game ID.");
      return;
    }
    if (!playerZoneId.trim()) {
      setError("Please enter your Game Name (nickname).");
      return;
    }
    if (!selectedPackage) {
      setError("Please select a top-up package to continue.");
      return;
    }
    if (!selectedPayment) {
      setError("Please select a payment method.");
      return;
    }

    if (selectedPayment.id === "user_wallet" && (currentUser?.walletBalance || 0) < currentTotal) {
      setError(`Insufficient wallet balance. You need LKR ${currentTotal.toFixed(2)} but only have LKR ${(currentUser?.walletBalance || 0).toFixed(2)}.`);
      return;
    }

    onInitiateCheckout({
      playerId,
      playerZoneId,
      selectedPackage,
      selectedPayment,
    });
  };

  const currentTotal = selectedPackage
    ? selectedPackage.price + (selectedPackage.price * (selectedPayment?.feePercentage || 0)) / 100
    : 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="game-details-root">
      {/* Game Info Summary Column */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.35 }}
        className="lg:col-span-1 space-y-6"
        id="game-info-column"
      >
        <div className="relative rounded-2xl bg-white/[0.03] border border-white/10 overflow-hidden shadow-xl backdrop-blur-md">
          <div className="h-40 relative">
            <img
              src={game.bannerUrl}
              alt={game.name}
              className="w-full h-full object-cover brightness-75"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#04040a] via-[#04040a]/35 to-transparent" />
          </div>
          <div className="p-6 relative -mt-10">
            <div className="w-16 h-16 rounded-2xl bg-[#04040a] p-1 border border-white/10 shadow-xl overflow-hidden mb-4">
              <div className="w-full h-full rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-black text-xl">
                {game.name[0]}
              </div>
            </div>
            <h2 className="text-xl font-black text-white tracking-tight">{game.name}</h2>
            <p className="text-xs text-cyan-400 font-bold mt-1 uppercase tracking-widest">{game.category}</p>
 
            <div className="mt-4 pt-4 border-t border-white/5 text-xs text-slate-400 space-y-2">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400" />
                <span>Immediate account verification</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400" />
                <span>Instant delivery in 3-5 minutes</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-cyan-400" />
                <span>100% legal & authorized top-up credits</span>
              </div>
            </div>
          </div>
        </div>
 
        {/* Info Card / Tutorial */}
        <div className="p-5 rounded-2xl bg-cyan-955/10 border border-cyan-500/20 text-xs text-slate-300 space-y-2.5 backdrop-blur-md">
          <div className="flex items-center gap-2 text-cyan-400 font-bold uppercase tracking-wider">
            <AlertCircle className="w-4 h-4" />
            <span>How to top up?</span>
          </div>
          <p>1. Fill in your Game ID and Game Name.</p>
          <p>2. Choose your package (e.g. Diamonds, UC, Gems).</p>
          <p>3. Select your preferred payment gateway.</p>
          <p>4. Complete the simulated secure checkout process.</p>
          <p>5. Track your order state in real time as the system processes it.</p>
        </div>
      </motion.div>
 
      {/* Main Topup Configuration Form */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.35, delay: 0.1 }}
        className="lg:col-span-2 space-y-8"
        id="form-column"
      >
        {/* Step 1: Account Info */}
        <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md" id="step-account">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center border border-cyan-500/30">
                1
              </span>
              <h3 className="font-bold text-white text-base">Enter Game Credentials</h3>
            </div>
            <button
              type="button"
              id="id-help-btn"
              onClick={() => setShowIdHelp(!showIdHelp)}
              className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1 transition-colors cursor-pointer font-semibold"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Where is my ID?</span>
            </button>
          </div>

          {showIdHelp && (
            <div className="p-4 rounded-xl bg-[#04040a]/90 border border-white/10 mb-4 text-xs text-slate-400 space-y-1.5" id="help-box">
              <p className="font-bold text-slate-200">Finding your Game ID:</p>
              {game.id === "mlbb" && (
                <p>Open Mobile Legends, tap your avatar. Under your nickname, find your User ID (e.g. 12345678) and Zone ID in parenthesis (e.g. 1234).</p>
              )}
              {game.id === "pubgm" && (
                <p>Open PUBG Mobile, go to your profile. Your numeric Character ID (e.g., 5123456789) is listed in the top left.</p>
              )}
              {game.id === "valorant" && (
                <p>Open Valorant or Riot client. Your Riot ID is your game name plus tag (e.g., PlayerName#1234).</p>
              )}
              {game.id === "genshin" && (
                <p>Open Genshin Impact. Your UID is visible in the bottom right corner of the screen at all times (e.g. 812345678).</p>
              )}
              {(!["mlbb", "pubgm", "valorant", "genshin"].includes(game.id)) && (
                <p>Open the game profile dashboard or settings screen to locate your unique user character registration ID.</p>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Game ID</label>
              <div className="relative">
                <input
                  id="player-id-input"
                  type="text"
                  placeholder={game.idPlaceholder || "e.g., 5123456789"}
                  value={playerId}
                  onChange={(e) => setPlayerId(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500/50 transition-all"
                />
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Game Name</label>
              <div className="relative">
                <input
                  id="player-zone-input"
                  type="text"
                  placeholder="e.g., PlayerNickname"
                  value={playerZoneId}
                  onChange={(e) => setPlayerZoneId(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500/50 transition-all"
                />
                <Layers className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
              </div>
            </div>
          </div>
        </div>

        {/* Step 2: Choose Package */}
        <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md" id="step-packages">
          <div className="flex items-center gap-3 mb-5">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center border border-cyan-500/30">
              2
            </span>
            <h3 className="font-bold text-white text-base">Select Top-Up Credits</h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {game.packages.map((pck) => {
              const isSelected = selectedPackage?.id === pck.id;
              return (
                <motion.button
                  key={pck.id}
                  id={`pkg-item-${pck.id}`}
                  onClick={() => setSelectedPackage(pck)}
                  whileHover={{ y: -3, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`relative p-4 rounded-xl text-left border transition-all duration-200 group flex flex-col justify-between h-28 cursor-pointer ${
                    isSelected
                      ? "bg-cyan-500/10 border-cyan-500/80 shadow-lg shadow-cyan-500/5"
                      : "bg-white/5 border-white/5 hover:border-cyan-500/50 hover:bg-white/[0.08]"
                  }`}
                >
                  {pck.popular && (
                    <span className="absolute -top-2 left-3 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider bg-gradient-to-r from-cyan-500 to-blue-600 text-black rounded">
                      Popular
                    </span>
                  )}
                  <div>
                    <span className={`text-xs font-semibold ${isSelected ? "text-cyan-400" : "text-slate-400 group-hover:text-slate-300"}`}>
                      {pck.unit}
                    </span>
                    <h4 className="font-bold text-white text-sm tracking-tight mt-0.5 line-clamp-2 leading-tight">
                      {pck.name.split("(")[0]}
                    </h4>
                  </div>
 
                  <div className="flex items-baseline gap-1.5 mt-2">
                    <span className="text-sm font-extrabold text-white">
                      LKR {pck.price.toFixed(2)}
                    </span>
                    {pck.originalPrice && (
                      <span className="text-[10px] text-slate-500 line-through">
                        LKR {pck.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
 
                  {isSelected && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute bottom-2 right-2 w-4 h-4 rounded-full bg-cyan-500 flex items-center justify-center shadow"
                    >
                      <Check className="w-3 h-3 text-black stroke-[3]" />
                    </motion.div>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Step 3: Choose Payment */}
        <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md" id="step-payment">
          <div className="flex items-center gap-3 mb-5">
            <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center border border-cyan-500/30">
              3
            </span>
            <h3 className="font-bold text-white text-base">Select Payment Gateway</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {displayedPaymentMethods.map((pm) => {
              const isSelected = selectedPayment?.id === pm.id;
              return (
                <motion.button
                  key={pm.id}
                  id={`pm-item-${pm.id}`}
                  onClick={() => setSelectedPayment(pm)}
                  whileHover={{ y: -2, scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  className={`p-3.5 rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                    isSelected
                      ? "bg-cyan-500/10 border-cyan-500/80 shadow-md shadow-cyan-500/5"
                      : "bg-white/5 border-white/5 hover:border-cyan-500/50 hover:bg-white/[0.08]"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#04040a] p-1 border border-white/5 flex items-center justify-center font-bold text-[11px] text-slate-300 overflow-hidden">
                      {pm.logo ? (
                        <img src={pm.logo} alt={pm.name} className="w-full h-full object-contain" />
                      ) : (
                        <span>{pm.name[0]}</span>
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-xs">{pm.name}</h4>
                      <p className="text-[10px] text-slate-500 capitalize mt-0.5">{pm.type} • Fee: {pm.feePercentage}%</p>
                    </div>
                  </div>
 
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    isSelected ? "border-cyan-500 bg-cyan-500" : "border-white/10"
                  }`}>
                    {isSelected && <Check className="w-2.5 h-2.5 text-black stroke-[3]" />}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Error notification */}
        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Submit Area */}
        <div className="p-6 rounded-2xl bg-gradient-to-r from-cyan-950/20 to-blue-950/15 border border-white/10 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Total Payable Amount</p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-white">
                LKR {currentTotal.toFixed(2)}
              </span>
              {selectedPayment && selectedPayment.feePercentage > 0 && (
                <span className="text-[10px] text-slate-400 font-semibold">
                  (incl. {selectedPayment.feePercentage}% gateway fee)
                </span>
              )}
            </div>
          </div>

          <button
            id="checkout-trigger-btn"
            onClick={handleCheckoutClick}
            disabled={!selectedPackage || !selectedPayment}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-sm shadow-[0_0_15px_rgba(6,182,212,0.3)] disabled:opacity-50 disabled:pointer-events-none hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer"
          >
            Buy Now & Top-Up
          </button>
        </div>
      </motion.div>
    </div>
  );
}
