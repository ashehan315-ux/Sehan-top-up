import React from "react";
import { Gamepad2, Search, MessageSquare, ShieldCheck, History, LogIn, LogOut, User as UserIcon, Settings } from "lucide-react";

interface HeaderProps {
  activeTab: "catalog" | "tracker" | "history" | "admin";
  setActiveTab: (tab: "catalog" | "tracker" | "history" | "admin") => void;
  openChat: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSearchSubmit: (e: React.FormEvent) => void;
  currentUser: any;
  onLogout: () => void;
  onOpenAuth: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  openChat,
  searchQuery,
  setSearchQuery,
  onSearchSubmit,
  currentUser,
  onLogout,
  onOpenAuth,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-[#04040a]/85 backdrop-blur-md border-b border-white/5" id="main-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab("catalog")} id="logo-container">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.4)]">
              <Gamepad2 className="w-5 h-5 text-black stroke-[2.5]" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tighter uppercase text-white">
                SEHAN<span className="text-cyan-400">TOPUP</span>
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5" id="desktop-nav">
            <button
              id="nav-btn-catalog"
              onClick={() => setActiveTab("catalog")}
              className={`px-4 py-2 rounded-lg text-xs uppercase tracking-widest font-bold transition-all ${
                activeTab === "catalog"
                  ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30"
                  : "text-slate-400 hover:text-white border border-transparent"
              }`}
            >
              Top-Up Games
            </button>
            <button
              id="nav-btn-tracker"
              onClick={() => setActiveTab("tracker")}
              className={`px-4 py-2 rounded-lg text-xs uppercase tracking-widest font-bold transition-all ${
                activeTab === "tracker"
                  ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30"
                  : "text-slate-400 hover:text-white border border-transparent"
              }`}
            >
              Order Tracker
            </button>
            <button
              id="nav-btn-history"
              onClick={() => setActiveTab("history")}
              className={`px-4 py-2 rounded-lg text-xs uppercase tracking-widest font-bold transition-all ${
                activeTab === "history"
                  ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30"
                  : "text-slate-400 hover:text-white border border-transparent"
              }`}
            >
              My Orders
            </button>
            {currentUser?.isAdmin && (
              <button
                id="nav-btn-admin"
                onClick={() => setActiveTab("admin")}
                className={`px-4 py-2 rounded-lg text-xs uppercase tracking-widest font-bold transition-all flex items-center gap-1.5 ${
                  activeTab === "admin"
                    ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-[0_0_15px_rgba(99,102,241,0.15)]"
                    : "text-indigo-400 hover:text-indigo-300 border border-transparent"
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>Admin Panel</span>
              </button>
            )}
          </nav>

          {/* Search bar & Live support bot */}
          <div className="flex items-center gap-4" id="header-right-controls">
            <form onSubmit={onSearchSubmit} className="relative hidden sm:block">
              <input
                id="header-search-input"
                type="text"
                placeholder="Search Order ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-36 lg:w-48 pl-9 pr-4 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 transition-all"
              />
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            </form>

            {/* Customer Session Details */}
            {currentUser ? (
              <div className="flex items-center gap-2.5" id="user-logged-in-sec">
                <div className="flex flex-col items-end text-right">
                  <span className="text-xs font-bold text-slate-200 flex items-center gap-1">
                    <UserIcon className="w-3 h-3 text-cyan-400" />
                    <span>{currentUser.username}</span>
                  </span>
                  <span className="text-[10px] text-cyan-400 font-black tracking-wide mt-1 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                    Wallet: LKR {currentUser.walletBalance !== undefined ? currentUser.walletBalance.toFixed(2) : "0.00"}
                  </span>
                  {currentUser.isAdmin && <span className="text-[9px] text-indigo-400 font-bold uppercase tracking-wider mt-0.5">Store Admin</span>}
                </div>
                <button
                  id="auth-logout-btn"
                  onClick={onLogout}
                  title="Sign Out"
                  className="p-2 rounded-lg bg-white/5 hover:bg-red-500/10 text-slate-400 hover:text-red-400 border border-white/5 hover:border-red-500/20 transition-all cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id="auth-login-trigger"
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white text-xs font-bold border border-white/10 transition-all cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sign In</span>
              </button>
            )}


          </div>
        </div>
      </div>

      {/* Mobile Nav Subbar */}
      <div className="md:hidden flex items-center justify-around py-2 border-t border-white/5 bg-[#04040a]/90" id="mobile-nav-subbar">
        <button
          id="mobile-nav-catalog"
          onClick={() => setActiveTab("catalog")}
          className={`flex flex-col items-center gap-1 text-[11px] font-medium py-1 w-1/4 transition-colors ${
            activeTab === "catalog" ? "text-cyan-400 font-semibold" : "text-slate-400"
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
          <span>Top-Up</span>
        </button>
        <button
          id="mobile-nav-tracker"
          onClick={() => setActiveTab("tracker")}
          className={`flex flex-col items-center gap-1 text-[11px] font-medium py-1 w-1/4 transition-colors ${
            activeTab === "tracker" ? "text-cyan-400 font-semibold" : "text-slate-400"
          }`}
        >
          <Search className="w-4 h-4" />
          <span>Track</span>
        </button>
        <button
          id="mobile-nav-history"
          onClick={() => setActiveTab("history")}
          className={`flex flex-col items-center gap-1 text-[11px] font-medium py-1 w-1/4 transition-colors ${
            activeTab === "history" ? "text-cyan-400 font-semibold" : "text-slate-400"
          }`}
        >
          <History className="w-4 h-4" />
          <span>Orders</span>
        </button>
        {currentUser?.isAdmin && (
          <button
            id="mobile-nav-admin"
            onClick={() => setActiveTab("admin")}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium py-1 w-1/4 transition-colors ${
              activeTab === "admin" ? "text-indigo-400 font-semibold" : "text-slate-400"
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Admin</span>
          </button>
        )}
      </div>
    </header>
  );
}
