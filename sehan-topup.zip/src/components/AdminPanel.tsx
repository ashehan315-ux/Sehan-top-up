import React, { useState, useEffect } from "react";
import { GameInfo, GamePackage, PaymentMethod, Order, OrderStatus, CarouselItem } from "../types";
import { 
  ShieldAlert, Database, Plus, Trash2, Edit, Save, X, RefreshCw, 
  Search, CheckCircle2, AlertCircle, ShoppingBag, Landmark, Key, Gamepad2, Settings,
  Users, BarChart3, TrendingUp, DollarSign, Calendar, Upload, Image, Palette, MessageSquare
} from "lucide-react";
import { THEMES } from "../theme";
import { 
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend 
} from "recharts";

interface AdminPanelProps {
  isAdmin: boolean;
  onClose: () => void;
  games: GameInfo[];
  paymentMethods: PaymentMethod[];
  activeTheme?: string;
  onChangeTheme?: (theme: string) => void;
  onRefreshData: () => void;
}

export default function AdminPanel({ 
  isAdmin, 
  onClose, 
  games, 
  paymentMethods, 
  activeTheme = "cyberpunk", 
  onChangeTheme, 
  onRefreshData 
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<"orders" | "games" | "payments" | "users" | "analytics" | "theme" | "sms" | "carousel">("orders");
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [orderQuery, setOrderQuery] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [saving, setSaving] = useState(false);

  // States for Carousel slider management
  const [carouselItems, setCarouselItems] = useState<CarouselItem[]>([]);
  const [loadingCarousel, setLoadingCarousel] = useState(false);
  const [carouselSaving, setCarouselSaving] = useState(false);
  const [uploadingSlides, setUploadingSlides] = useState<{ [slideId: string]: boolean }>({});

  // States for SMS logs
  const [smsLogs, setSmsLogs] = useState<any[]>([]);
  const [loadingSms, setLoadingSms] = useState(false);
  const [smsConfig, setSmsConfig] = useState<any>({
    hasTwilio: false,
    hasNotifyLk: false,
    activeGateway: "None",
    twilioConfigured: false,
    notifyLkConfigured: false,
  });

  // States for Registered Users
  const [users, setUsers] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [userQuery, setUserQuery] = useState("");
  const [adjustingUser, setAdjustingUser] = useState<any | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<string>("");
  const [adjustReason, setAdjustReason] = useState<string>("Remaining Balance / Refund");

  // States for Analytics Filters
  const [startDateFilter, setStartDateFilter] = useState("");
  const [endDateFilter, setEndDateFilter] = useState("");
  const [chartType, setChartType] = useState<"both" | "daily" | "weekly">("both");

  // States for Editing Games & Packages
  const [editedGames, setEditedGames] = useState<GameInfo[]>([]);
  const [selectedGameForPackage, setSelectedGameForPackage] = useState<string | null>(null);

  // States and handler for uploading images
  const [uploadingField, setUploadingField] = useState<{ [gameId: string]: { [field: string]: boolean } }>({});
  const [uploadError, setUploadError] = useState("");

  const handleImageUpload = async (gameId: string, field: "iconUrl" | "bannerUrl", file: File) => {
    if (!file) return;

    setUploadingField(prev => ({
      ...prev,
      [gameId]: {
        ...(prev[gameId] || {}),
        [field]: true
      }
    }));
    setUploadError("");

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (err) => reject(err);
        reader.readAsDataURL(file);
      });

      const base64Data = await base64Promise;

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          filename: file.name,
          base64Data
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to upload image");
      }

      const { url } = await res.json();

      handleUpdateGameField(gameId, field, url);
      setSuccessMsg("Photo uploaded and updated successfully!");
      setTimeout(() => setSuccessMsg(""), 3000);
    } catch (err: any) {
      console.error(err);
      setUploadError(err.message || "Failed to upload photo.");
    } finally {
      setUploadingField(prev => ({
        ...prev,
        [gameId]: {
          ...(prev[gameId] || {}),
          [field]: false
        }
      }));
    }
  };

  // Custom confirmation modal state to bypass iframe browser confirmation restrictions
  interface ConfirmModalState {
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }
  const [confirmModal, setConfirmModal] = useState<ConfirmModalState | null>(null);

  // States for Editing Payment Methods
  const [editedPayments, setEditedPayments] = useState<PaymentMethod[]>([]);

  // Initialize editable structures when data changes
  useEffect(() => {
    setEditedGames(JSON.parse(JSON.stringify(games)));
  }, [games]);

  useEffect(() => {
    setEditedPayments(JSON.parse(JSON.stringify(paymentMethods)));
  }, [paymentMethods]);

  // Fetch all orders on load or refresh
  const fetchAllOrders = async () => {
    setLoadingOrders(true);
    setErrorMsg("");
    try {
      const res = await fetch("/api/admin/orders");
      if (!res.ok) throw new Error("Failed to fetch admin orders registry");
      const data = await res.json();
      setOrders(data);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to load orders");
    } finally {
      setLoadingOrders(false);
    }
  };

  // Fetch all registered users
  const fetchAllUsers = async () => {
    setLoadingUsers(true);
    setErrorMsg("");
    try {
      const res = await fetch("/api/admin/users");
      if (!res.ok) throw new Error("Failed to fetch registered users");
      const data = await res.json();
      setUsers(data);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to load registered users");
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleInitiateAdjustWallet = (user: any) => {
    setAdjustingUser(user);
    setAdjustAmount("");
    setAdjustReason("Remaining Balance / Refund");
  };

  const handleSaveWalletAdjustment = async () => {
    if (!adjustingUser) return;
    const amount = parseFloat(adjustAmount);
    if (isNaN(amount)) {
      alert("Please enter a valid numeric amount.");
      return;
    }

    try {
      const res = await fetch(`/api/admin/users/${adjustingUser.id}/adjust-wallet`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount, reason: adjustReason }),
      });

      if (!res.ok) throw new Error("Failed to adjust wallet balance");
      const updatedUser = await res.json();
      
      // Update local users array
      setUsers(users.map((u) => (u.id === adjustingUser.id ? updatedUser : u)));
      setSuccessMsg(`Wallet balance for ${adjustingUser.username} updated by LKR ${amount.toFixed(2)}!`);
      setAdjustingUser(null);
      setAdjustAmount("");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to adjust balance");
    }
  };

  // Fetch all automated dispatch SMS logs
  const fetchSmsLogs = async () => {
    setLoadingSms(true);
    setErrorMsg("");
    try {
      const res = await fetch("/api/admin/sms-logs");
      if (!res.ok) throw new Error("Failed to fetch SMS logs");
      const data = await res.json();
      setSmsLogs(data);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to load SMS logs");
    } finally {
      setLoadingSms(false);
    }
  };

  const fetchSmsConfig = async () => {
    try {
      const res = await fetch("/api/admin/sms-config-status");
      if (res.ok) {
        const data = await res.json();
        setSmsConfig(data);
      }
    } catch (err) {
      console.error("Failed to fetch SMS config status:", err);
    }
  };

  const fetchCarouselItems = async () => {
    setLoadingCarousel(true);
    try {
      const res = await fetch("/api/carousel");
      if (res.ok) {
        const data = await res.json();
        setCarouselItems(data);
      }
    } catch (err) {
      console.error("Failed to load carousel list in Admin Panel", err);
    } finally {
      setLoadingCarousel(false);
    }
  };

  const handleSaveCarouselItems = async (itemsToSave: CarouselItem[]) => {
    setCarouselSaving(true);
    setErrorMsg("");
    setSuccessMsg("");
    try {
      const res = await fetch("/api/admin/carousel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ carousel: itemsToSave }),
      });
      if (res.ok) {
        const data = await res.json();
        setCarouselItems(data.carousel);
        setSuccessMsg("Home Carousel Slider settings saved successfully on server!");
        setTimeout(() => setSuccessMsg(""), 3500);
        onRefreshData();
      } else {
        throw new Error("Could not save Carousel on server backend");
      }
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to save Carousel settings.");
    } finally {
      setCarouselSaving(false);
    }
  };

  const handleCarouselImageUpload = async (slideId: string, file: File) => {
    if (!file) return;

    setUploadingSlides(prev => ({ ...prev, [slideId]: true }));
    setErrorMsg("");
    setSuccessMsg("");

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (err) => reject(err);
        reader.readAsDataURL(file);
      });

      const base64Data = await base64Promise;

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          filename: `slide_${Date.now()}_${file.name}`,
          base64Data
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to upload slide asset");
      }

      const { url } = await res.json();

      setCarouselItems(prev => prev.map(item => item.id === slideId ? { ...item, url } : item));
      setSuccessMsg("Slide media uploaded successfully! Click 'Save All Slider Changes' to apply.");
      setTimeout(() => setSuccessMsg(""), 4000);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Failed to upload slide asset.");
    } finally {
      setUploadingSlides(prev => ({ ...prev, [slideId]: false }));
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchAllOrders();
      fetchAllUsers();
      fetchSmsLogs();
      fetchSmsConfig();
      fetchCarouselItems();
    }
  }, [isAdmin]);


  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto my-12 p-8 text-center rounded-2xl bg-red-500/10 border border-red-500/20 text-white" id="admin-unauth">
        <ShieldAlert className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold mb-2">Access Denied</h3>
        <p className="text-slate-400 mb-6 text-sm">You do not have administrative privileges to view this section.</p>
        <button onClick={onClose} className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-all font-bold text-xs">
          Return to Store
        </button>
      </div>
    );
  }

  // Handle order status changes directly
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    setErrorMsg("");
    setSuccessMsg("");
    try {
      const response = await fetch(`/api/orders/${orderId}/update-status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!response.ok) throw new Error("Could not update order status on the server");
      const updatedOrder = await response.json();
      setOrders(orders.map(o => o.id === orderId ? updatedOrder : o));
      setSuccessMsg(`Order ${orderId} status successfully updated to "${status.replace("_", " ")}"!`);
      onRefreshData();
    } catch (err: any) {
      setErrorMsg(err.message || "Error updating order status.");
    }
  };

  // GAMES & PACKAGES EDITING HANDLERS
  const handleSaveGames = async (catalogToSave: GameInfo[]) => {
    setSaving(true);
    setErrorMsg("");
    setSuccessMsg("");
    try {
      const response = await fetch("/api/admin/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ games: catalogToSave }),
      });
      if (!response.ok) throw new Error("Failed to save games catalog to file backend.");
      setSuccessMsg("Games and packages updated successfully on the server!");
      onRefreshData();
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to save games");
    } finally {
      setSaving(false);
    }
  };

  const handleAddGame = () => {
    const newId = `game-${Date.now()}`;
    const newGame: GameInfo = {
      id: newId,
      name: "New Game Title",
      category: "Mobile Games",
      iconUrl: "https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?w=150&auto=format&fit=crop&q=80",
      bannerUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80",
      idLabel: "User ID",
      idPlaceholder: "Enter User ID",
      packages: []
    };
    const updated = [...editedGames, newGame];
    setEditedGames(updated);
    handleSaveGames(updated);
  };

  const handleUpdateGameField = (gameId: string, field: keyof GameInfo, value: any) => {
    const updated = editedGames.map(g => {
      if (g.id === gameId) {
        return { ...g, [field]: value };
      }
      return g;
    });
    setEditedGames(updated);
  };

  const handleDeleteGame = (gameId: string) => {
    const game = editedGames.find(g => g.id === gameId);
    setConfirmModal({
      isOpen: true,
      title: "Delete Game",
      message: `Are you sure you want to delete "${game?.name || 'this game'}" and all of its associated packages? This action cannot be undone.`,
      onConfirm: () => {
        const updated = editedGames.filter(g => g.id !== gameId);
        setEditedGames(updated);
        handleSaveGames(updated);
        if (selectedGameForPackage === gameId) setSelectedGameForPackage(null);
      }
    });
  };

  // PACKAGES INSIDE GAMES
  const handleAddPackage = (gameId: string) => {
    const updated = editedGames.map(g => {
      if (g.id === gameId) {
        const newPackage: GamePackage = {
          id: `pckg-${Date.now()}`,
          name: "100 Gold/Points/Diamonds",
          price: 1.99,
          value: 100,
          unit: "Points",
          popular: false
        };
        return { ...g, packages: [...g.packages, newPackage] };
      }
      return g;
    });
    setEditedGames(updated);
    handleSaveGames(updated);
  };

  const handleUpdatePackageField = (gameId: string, packageId: string, field: keyof GamePackage, value: any) => {
    const updated = editedGames.map(g => {
      if (g.id === gameId) {
        const updatedPackages = g.packages.map(p => {
          if (p.id === packageId) {
            return { ...p, [field]: value };
          }
          return p;
        });
        return { ...g, packages: updatedPackages };
      }
      return g;
    });
    setEditedGames(updated);
  };

  const handleDeletePackage = (gameId: string, packageId: string) => {
    const updated = editedGames.map(g => {
      if (g.id === gameId) {
        return { ...g, packages: g.packages.filter(p => p.id !== packageId) };
      }
      return g;
    });
    setEditedGames(updated);
    handleSaveGames(updated);
  };

  // PAYMENT METHODS HANDLERS
  const handleSavePayments = async (paymentsToSave: PaymentMethod[]) => {
    setSaving(true);
    setErrorMsg("");
    setSuccessMsg("");
    try {
      const response = await fetch("/api/admin/payment-methods", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paymentMethods: paymentsToSave }),
      });
      if (!response.ok) throw new Error("Failed to save payment methods config to file backend.");
      setSuccessMsg("Payment methods successfully saved!");
      onRefreshData();
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to save payment methods");
    } finally {
      setSaving(false);
    }
  };

  const handleAddPayment = () => {
    const newId = `pay-${Date.now()}`;
    const newPayment: PaymentMethod = {
      id: newId,
      name: "New Pay Gateway",
      type: "wallet",
      logo: "https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=100&auto=format&fit=crop&q=80",
      instructions: "Transfer to our wallet number, and write transaction proof ID below.",
      accountNumber: "+880 1234 56789",
      feePercentage: 1.0
    };
    const updated = [...editedPayments, newPayment];
    setEditedPayments(updated);
    handleSavePayments(updated);
  };

  const handleUpdatePaymentField = (payId: string, field: keyof PaymentMethod, value: any) => {
    const updated = editedPayments.map(p => {
      if (p.id === payId) {
        return { ...p, [field]: value };
      }
      return p;
    });
    setEditedPayments(updated);
  };

  const handleDeletePayment = (payId: string) => {
    const payment = editedPayments.find(p => p.id === payId);
    setConfirmModal({
      isOpen: true,
      title: "Delete Payment Method",
      message: `Are you sure you want to delete the "${payment?.name || 'this payment'}" gateway? Customers will no longer be able to select this payment option.`,
      onConfirm: () => {
        const updated = editedPayments.filter(p => p.id !== payId);
        setEditedPayments(updated);
        handleSavePayments(updated);
      }
    });
  };

  // Filtered orders for view
  const filteredOrders = orders.filter(o => 
    o.id.toLowerCase().includes(orderQuery.toLowerCase()) ||
    o.playerId.toLowerCase().includes(orderQuery.toLowerCase()) ||
    (o.username && o.username.toLowerCase().includes(orderQuery.toLowerCase())) ||
    (o.transactionId && o.transactionId.toLowerCase().includes(orderQuery.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="admin-dashboard-root">
      {/* Header Area */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 border-b border-white/5 pb-6">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-widest">
            <Settings className="w-4 h-4" />
            <span>Sehan Topup Backoffice Control Panel</span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-white mt-1">
            Admin Console
          </h2>
          <p className="text-sm text-slate-400 mt-1">Logged in as: <strong className="text-indigo-300">Sehan 123</strong> (Super Administrator)</p>
        </div>
        <button 
          id="admin-exit-btn"
          onClick={onClose}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-all font-bold text-xs cursor-pointer"
        >
          <X className="w-4 h-4" />
          <span>Exit Admin View</span>
        </button>
      </div>

      {/* Notifications banner */}
      {(errorMsg || successMsg) && (
        <div className="mb-6 space-y-3" id="admin-banners">
          {errorMsg && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400 flex items-center gap-2.5">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
          {successMsg && (
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-sm text-emerald-400 flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}
        </div>
      )}

      {/* Admin Tab Buttons */}
      <div className="flex flex-wrap items-center gap-2 mb-8 bg-white/5 p-1 rounded-xl w-fit border border-white/5" id="admin-tabs">
        <button
          id="admin-tab-btn-orders"
          onClick={() => setActiveTab("orders")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "orders"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Manage Orders ({orders.length})</span>
        </button>
        <button
          id="admin-tab-btn-games"
          onClick={() => setActiveTab("games")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "games"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
          <span>Games & Packages</span>
        </button>
        <button
          id="admin-tab-btn-payments"
          onClick={() => setActiveTab("payments")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "payments"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>Payment Gateways</span>
        </button>
        <button
          id="admin-tab-btn-users"
          onClick={() => setActiveTab("users")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "users"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Registered Users ({users.length})</span>
        </button>
        <button
          id="admin-tab-btn-analytics"
          onClick={() => setActiveTab("analytics")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "analytics"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Sales & Analytics</span>
        </button>
        <button
          id="admin-tab-btn-theme"
          onClick={() => setActiveTab("theme")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "theme"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Theme Settings</span>
        </button>
        <button
          id="admin-tab-btn-sms"
          onClick={() => setActiveTab("sms")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "sms"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>SMS Alert Logs ({smsLogs.length})</span>
        </button>
        <button
          id="admin-tab-btn-carousel"
          onClick={() => setActiveTab("carousel")}
          className={`px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === "carousel"
              ? "bg-cyan-500 text-black shadow-lg"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Image className="w-4 h-4" />
          <span>Home Media Slider</span>
        </button>
      </div>

      {/* TAB 1: ORDER LOGS */}
      {activeTab === "orders" && (
        <div className="space-y-6" id="admin-orders-tab">
          {/* Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-4 justify-between bg-white/5 p-4 rounded-2xl border border-white/5">
            <div className="relative w-full sm:max-w-md">
              <input
                id="admin-order-search"
                type="text"
                placeholder="Search orders (ID, player, customer, txn proof)..."
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-xs rounded-lg bg-white/5 border border-white/10 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 transition-all"
              />
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            </div>
            <button
              id="admin-order-refresh"
              onClick={fetchAllOrders}
              disabled={loadingOrders}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingOrders ? "animate-spin" : ""}`} />
              <span>Refresh Orders Log</span>
            </button>
          </div>

          {/* Orders Table/List */}
          {loadingOrders ? (
            <div className="text-center py-12 text-slate-500 text-xs font-bold" id="admin-orders-loading">
              <span className="inline-block w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mb-2" />
              <p>Fetching store orders registries from server...</p>
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white/5 border border-white/5 text-slate-500 text-xs" id="admin-orders-empty">
              No matching orders found on the server.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-white/5 bg-white/5" id="admin-orders-list">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#0c0c14] border-b border-white/10 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="p-4">Order ID & Date</th>
                    <th className="p-4">Customer Account</th>
                    <th className="p-4">Game Details</th>
                    <th className="p-4">Sender Details & Price</th>
                    <th className="p-4">Payment Proof</th>
                    <th className="p-4">Status Override</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-white/5 transition-colors" id={`admin-tr-${order.id}`}>
                      {/* ID & DATE */}
                      <td className="p-4">
                        <div className="font-mono font-extrabold text-cyan-400">{order.id}</div>
                        <div className="text-[10px] text-slate-500 mt-1">
                          {new Date(order.createdAt).toLocaleString()}
                        </div>
                      </td>

                      {/* USER */}
                      <td className="p-4">
                        <div className="font-semibold text-slate-200">
                          {order.username || "Anonymous"}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5">
                          ID: {order.userId || "N/A"}
                        </div>
                      </td>

                      {/* GAME & PACKAGE */}
                      <td className="p-4">
                        <div className="font-bold text-slate-300">{order.gameName}</div>
                        <div className="text-[10px] text-indigo-400 mt-0.5">{order.packageName}</div>
                        <div className="text-[10px] text-slate-500 mt-1">
                          Game ID: <span className="font-mono font-bold text-slate-400">{order.playerId}</span>{order.playerZoneId ? ` | Game Name: ${order.playerZoneId}` : ""}
                        </div>
                      </td>

                      {/* PAYMENT & SENDER */}
                      <td className="p-4">
                        <div className="font-bold text-emerald-400">LKR {order.price.toFixed(2)}</div>
                        <div className="text-[10px] text-slate-500 mt-1">
                          Via: <span className="text-slate-400">{order.paymentMethodName}</span>
                        </div>
                        {order.senderNumber && (
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Sender Wallet: {order.senderNumber}
                          </div>
                        )}
                      </td>

                      {/* TRANSACTION PROOF */}
                      <td className="p-4">
                        {order.transactionId ? (
                          <div className="space-y-1">
                            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 font-mono font-bold border border-cyan-500/20">
                              {order.transactionId}
                            </span>
                            {order.cardLast4 && (
                              <div className="text-[10px] text-slate-500">Card ending: •••• {order.cardLast4}</div>
                            )}
                            {order.receiptUrl && (
                              <div className="mt-1 flex items-center gap-1.5">
                                <a 
                                  href={order.receiptUrl} 
                                  target="_blank" 
                                  rel="noreferrer" 
                                  className="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                                >
                                  <Image className="w-3 h-3 shrink-0" />
                                  <span>View Receipt</span>
                                </a>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <span className="text-[10px] text-yellow-500 italic">No proof uploaded yet</span>
                            {order.receiptUrl && (
                              <div className="mt-1 flex items-center gap-1.5">
                                <a 
                                  href={order.receiptUrl} 
                                  target="_blank" 
                                  rel="noreferrer" 
                                  className="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                                >
                                  <Image className="w-3 h-3 shrink-0" />
                                  <span>View Receipt</span>
                                </a>
                              </div>
                            )}
                          </div>
                        )}
                      </td>

                      {/* STATUS OVERRIDE ACTIONS */}
                      <td className="p-4">
                        <div className="flex flex-col gap-1 w-36">
                          <span className={`text-[9px] px-2 py-0.5 rounded w-fit uppercase font-bold tracking-wider mb-1.5 ${
                            order.status === "completed" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                            order.status === "failed" ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                            order.status === "processing" ? "bg-purple-500/10 text-purple-400 border border-purple-500/20" :
                            order.status === "verifying" ? "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20" :
                            "bg-slate-500/10 text-slate-400 border border-slate-500/20"
                          }`}>
                            {order.status.replace("_", " ")}
                          </span>

                          <select
                            id={`status-select-${order.id}`}
                            value={order.status}
                            onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                            className="w-full bg-[#0c0c14] border border-white/15 text-[11px] rounded p-1 text-slate-300 focus:outline-none focus:border-cyan-500/50"
                          >
                            <option value="awaiting_payment">Awaiting Pay</option>
                            <option value="verifying">Verify Payment</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed (Deliver)</option>
                            <option value="failed">Failed / Cancel</option>
                          </select>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GAMES CATALOG */}
      {activeTab === "games" && (
        <div className="space-y-8" id="admin-games-tab">
          <div className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
            <div>
              <h3 className="text-lg font-bold text-white">Active Games ({editedGames.length})</h3>
              <p className="text-xs text-slate-400">Add or modify top-up games, fields, and pricing packages</p>
            </div>
            <button
              id="admin-add-game-btn"
              onClick={handleAddGame}
              disabled={saving}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Game</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left: Games List */}
            <div className="lg:col-span-1 space-y-3 bg-white/5 p-4 rounded-2xl border border-white/5" id="admin-games-list">
              <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">Game Directory</span>
              {editedGames.map((game) => (
                <div 
                  key={game.id} 
                  id={`admin-game-card-${game.id}`}
                  onClick={() => setSelectedGameForPackage(selectedGameForPackage === game.id ? null : game.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left flex items-center justify-between ${
                    selectedGameForPackage === game.id 
                      ? "bg-cyan-500/10 border-cyan-500/50" 
                      : "bg-[#0c0c14] hover:bg-white/5 border-white/10"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img referrerPolicy="no-referrer" src={game.iconUrl} alt={game.name} className="w-10 h-10 rounded-lg object-cover bg-white/5 shrink-0" />
                    <div>
                      <h4 className="font-bold text-xs text-slate-100">{game.name}</h4>
                      <p className="text-[10px] text-slate-500 mt-0.5">{game.category} • {game.packages.length} packages</p>
                    </div>
                  </div>
                  <button
                    id={`delete-game-btn-${game.id}`}
                    onClick={(e) => { e.stopPropagation(); handleDeleteGame(game.id); }}
                    className="p-1 text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Right: Detailed Fields and Packages Editor */}
            <div className="lg:col-span-2">
              {selectedGameForPackage ? (
                (() => {
                  const currentGame = editedGames.find(g => g.id === selectedGameForPackage);
                  if (!currentGame) return null;
                  return (
                    <div className="space-y-6 bg-white/5 p-6 rounded-2xl border border-white/5 text-left" id="admin-packages-detail-panel">
                      {/* Edit Fields */}
                      <div className="border-b border-white/5 pb-4">
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="text-md font-bold text-white flex items-center gap-2">
                            <Gamepad2 className="w-5 h-5 text-cyan-400" />
                            <span>Game Details: {currentGame.name}</span>
                          </h4>
                          <button
                            id={`save-game-details-${currentGame.id}`}
                            onClick={() => handleSaveGames(editedGames)}
                            disabled={saving}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black text-[11px] font-bold"
                          >
                            <Save className="w-3.5 h-3.5" />
                            <span>Save Details</span>
                          </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[10px] text-slate-400 uppercase font-bold mb-1">Game Name</label>
                            <input
                              type="text"
                              value={currentGame.name}
                              onChange={(e) => handleUpdateGameField(currentGame.id, "name", e.target.value)}
                              className="w-full bg-[#0c0c14] border border-white/15 text-xs rounded-lg p-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-400 uppercase font-bold mb-1">Category</label>
                            <input
                              type="text"
                              value={currentGame.category}
                              onChange={(e) => handleUpdateGameField(currentGame.id, "category", e.target.value)}
                              className="w-full bg-[#0c0c14] border border-white/15 text-xs rounded-lg p-2 text-white"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <label className="block text-[10px] text-slate-400 uppercase font-bold">Icon Image</label>
                            <div className="flex items-center gap-3 bg-[#0c0c14] border border-white/15 p-2.5 rounded-lg">
                              {currentGame.iconUrl ? (
                                <img referrerPolicy="no-referrer" src={currentGame.iconUrl} alt="Icon Preview" className="w-12 h-12 rounded-lg object-cover bg-white/5 border border-white/10 shrink-0" />
                              ) : (
                                <div className="w-12 h-12 rounded-lg bg-white/5 border border-dashed border-white/10 flex items-center justify-center text-slate-500 shrink-0">
                                  <Image className="w-5 h-5" />
                                </div>
                              )}
                              <div className="flex-grow space-y-1.5">
                                <input
                                  type="text"
                                  placeholder="Icon URL"
                                  value={currentGame.iconUrl}
                                  onChange={(e) => handleUpdateGameField(currentGame.id, "iconUrl", e.target.value)}
                                  className="w-full bg-white/5 border border-white/10 text-xs rounded p-1 text-white focus:outline-none focus:border-cyan-500/50"
                                />
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] text-slate-500 font-medium">Or choose local photo:</span>
                                  <label className="flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-bold text-black bg-cyan-400 hover:bg-cyan-300 rounded cursor-pointer transition-colors">
                                    {uploadingField[currentGame.id]?.iconUrl ? (
                                      <>
                                        <RefreshCw className="w-3 h-3 animate-spin" />
                                        <span>Uploading...</span>
                                      </>
                                    ) : (
                                      <>
                                        <Upload className="w-3 h-3" />
                                        <span>Upload Photo</span>
                                      </>
                                    )}
                                    <input
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      disabled={uploadingField[currentGame.id]?.iconUrl}
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) handleImageUpload(currentGame.id, "iconUrl", file);
                                      }}
                                    />
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <label className="block text-[10px] text-slate-400 uppercase font-bold">Banner Image</label>
                            <div className="flex items-center gap-3 bg-[#0c0c14] border border-white/15 p-2.5 rounded-lg">
                              {currentGame.bannerUrl ? (
                                <img referrerPolicy="no-referrer" src={currentGame.bannerUrl} alt="Banner Preview" className="w-20 h-12 rounded-lg object-cover bg-white/5 border border-white/10 shrink-0" />
                              ) : (
                                <div className="w-20 h-12 rounded-lg bg-white/5 border border-dashed border-white/10 flex items-center justify-center text-slate-500 shrink-0">
                                  <Image className="w-6 h-6" />
                                </div>
                              )}
                              <div className="flex-grow space-y-1.5">
                                <input
                                  type="text"
                                  placeholder="Banner URL"
                                  value={currentGame.bannerUrl}
                                  onChange={(e) => handleUpdateGameField(currentGame.id, "bannerUrl", e.target.value)}
                                  className="w-full bg-white/5 border border-white/10 text-xs rounded p-1 text-white focus:outline-none focus:border-cyan-500/50"
                                />
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] text-slate-500 font-medium">Or choose local photo:</span>
                                  <label className="flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-bold text-black bg-cyan-400 hover:bg-cyan-300 rounded cursor-pointer transition-colors">
                                    {uploadingField[currentGame.id]?.bannerUrl ? (
                                      <>
                                        <RefreshCw className="w-3 h-3 animate-spin" />
                                        <span>Uploading...</span>
                                      </>
                                    ) : (
                                      <>
                                        <Upload className="w-3 h-3" />
                                        <span>Upload Photo</span>
                                      </>
                                    )}
                                    <input
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      disabled={uploadingField[currentGame.id]?.bannerUrl}
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) handleImageUpload(currentGame.id, "bannerUrl", file);
                                      }}
                                    />
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>

                          {uploadError && (
                            <div className="sm:col-span-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 p-2.5 rounded-lg flex items-center gap-2">
                              <AlertCircle className="w-4 h-4 shrink-0" />
                              <span>{uploadError}</span>
                            </div>
                          )}

                          <div>
                            <label className="block text-[10px] text-slate-400 uppercase font-bold mb-1">Account ID Input Label</label>
                            <input
                              type="text"
                              value={currentGame.idLabel}
                              onChange={(e) => handleUpdateGameField(currentGame.id, "idLabel", e.target.value)}
                              className="w-full bg-[#0c0c14] border border-white/15 text-xs rounded-lg p-2 text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-400 uppercase font-bold mb-1">Zone ID Label (Optional)</label>
                            <input
                              type="text"
                              value={currentGame.zoneLabel || ""}
                              onChange={(e) => handleUpdateGameField(currentGame.id, "zoneLabel", e.target.value)}
                              placeholder="e.g., Zone ID"
                              className="w-full bg-[#0c0c14] border border-white/15 text-xs rounded-lg p-2 text-white"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Package Editor */}
                      <div>
                        <div className="flex justify-between items-center mb-3">
                          <h5 className="text-xs font-bold uppercase tracking-wider text-slate-300">Top-Up Packages ({currentGame.packages.length})</h5>
                          <button
                            id="admin-add-package-btn"
                            onClick={() => handleAddPackage(currentGame.id)}
                            className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 text-xs font-bold"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add Package</span>
                          </button>
                        </div>

                        {currentGame.packages.length === 0 ? (
                          <div className="p-6 text-center text-slate-500 text-xs border border-dashed border-white/10 rounded-xl">
                            No packages configured for this game yet. Click "Add Package" above.
                          </div>
                        ) : (
                          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                            {currentGame.packages.map((pkg) => (
                              <div key={pkg.id} className="p-3 bg-[#0c0c14] border border-white/10 rounded-xl flex flex-col md:flex-row md:items-center gap-3">
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 flex-grow">
                                  <div>
                                    <label className="block text-[9px] text-slate-500 uppercase font-semibold">Package Title</label>
                                    <input
                                      type="text"
                                      value={pkg.name}
                                      onChange={(e) => handleUpdatePackageField(currentGame.id, pkg.id, "name", e.target.value)}
                                      className="w-full bg-white/5 border border-white/10 text-[11px] rounded p-1 text-slate-200"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[9px] text-slate-500 uppercase font-semibold">Price (LKR)</label>
                                    <input
                                      type="number"
                                      step="0.01"
                                      value={pkg.price}
                                      onChange={(e) => handleUpdatePackageField(currentGame.id, pkg.id, "price", parseFloat(e.target.value) || 0)}
                                      className="w-full bg-white/5 border border-white/10 text-[11px] rounded p-1 text-slate-200"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[9px] text-slate-500 uppercase font-semibold">Original Price (LKR)</label>
                                    <input
                                      type="number"
                                      step="0.01"
                                      value={pkg.originalPrice || ""}
                                      onChange={(e) => handleUpdatePackageField(currentGame.id, pkg.id, "originalPrice", parseFloat(e.target.value) || undefined)}
                                      className="w-full bg-white/5 border border-white/10 text-[11px] rounded p-1 text-slate-200"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[9px] text-slate-500 uppercase font-semibold">Items Amount & Unit</label>
                                    <div className="flex gap-1">
                                      <input
                                        type="number"
                                        placeholder="Value"
                                        value={pkg.value}
                                        onChange={(e) => handleUpdatePackageField(currentGame.id, pkg.id, "value", parseInt(e.target.value) || 0)}
                                        className="w-1/2 bg-white/5 border border-white/10 text-[11px] rounded p-1 text-slate-200"
                                      />
                                      <input
                                        type="text"
                                        placeholder="Unit"
                                        value={pkg.unit}
                                        onChange={(e) => handleUpdatePackageField(currentGame.id, pkg.id, "unit", e.target.value)}
                                        className="w-1/2 bg-white/5 border border-white/10 text-[11px] rounded p-1 text-slate-200"
                                      />
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center gap-2 justify-between shrink-0 md:pt-4">
                                  <label className="flex items-center gap-1.5 text-[11px] text-slate-400 cursor-pointer">
                                    <input
                                      type="checkbox"
                                      checked={pkg.popular || false}
                                      onChange={(e) => handleUpdatePackageField(currentGame.id, pkg.id, "popular", e.target.checked)}
                                      className="rounded bg-white/5 border-white/10 text-cyan-500 focus:ring-0"
                                    />
                                    <span>Popular</span>
                                  </label>
                                  <button
                                    id={`delete-pkg-btn-${pkg.id}`}
                                    onClick={() => handleDeletePackage(currentGame.id, pkg.id)}
                                    className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex justify-end mt-4 pt-4 border-t border-white/5">
                          <button
                            id="admin-save-all-packages-btn"
                            onClick={() => handleSaveGames(editedGames)}
                            disabled={saving}
                            className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black transition-all font-bold text-xs"
                          >
                            {saving ? (
                              <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                            ) : (
                              <>
                                <Save className="w-4 h-4" />
                                <span>Save All Package Changes</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="h-full flex items-center justify-center p-12 text-center rounded-2xl bg-white/5 border border-white/5 text-slate-500 text-sm">
                  Select a game from the directory on the left to edit its general details and pricing packages.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PAYMENT GATEWAYS */}
      {activeTab === "payments" && (
        <div className="space-y-6" id="admin-payments-tab">
          <div className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
            <div>
              <h3 className="text-lg font-bold text-white">Payment Methods ({editedPayments.length})</h3>
              <p className="text-xs text-slate-400">Configure retail numbers, card details, instructions, or fee rates</p>
            </div>
            <button
              id="admin-add-payment-btn"
              onClick={handleAddPayment}
              disabled={saving}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Payment Gateway</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="admin-payments-grid">
            {editedPayments.map((pay) => (
              <div key={pay.id} className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-4 text-left" id={`admin-pay-card-${pay.id}`}>
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <div className="flex items-center gap-3">
                    <img referrerPolicy="no-referrer" src={pay.logo} alt={pay.name} className="w-10 h-10 rounded-lg object-cover bg-white/5 shrink-0" />
                    <div>
                      <input
                        type="text"
                        value={pay.name}
                        onChange={(e) => handleUpdatePaymentField(pay.id, "name", e.target.value)}
                        className="bg-transparent border-b border-transparent hover:border-white/10 focus:border-cyan-500 font-bold text-sm text-white focus:outline-none"
                      />
                      <div className="text-[10px] text-slate-500 mt-0.5">ID: {pay.id}</div>
                    </div>
                  </div>
                  <button
                    id={`delete-pay-btn-${pay.id}`}
                    onClick={() => handleDeletePayment(pay.id)}
                    className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Gateway Type</label>
                    <select
                      value={pay.type}
                      onChange={(e) => handleUpdatePaymentField(pay.id, "type", e.target.value)}
                      className="w-full bg-[#0c0c14] border border-white/10 rounded p-1.5 text-slate-200"
                    >
                      <option value="wallet">Mobile Wallet</option>
                      <option value="bank">Bank Transfer</option>
                      <option value="card">Credit Card</option>
                      <option value="qr">QR Scan</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Fee Rate (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={pay.feePercentage}
                      onChange={(e) => handleUpdatePaymentField(pay.id, "feePercentage", parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#0c0c14] border border-white/10 rounded p-1.5 text-slate-200"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Retail Target Number / Account Number</label>
                    <input
                      type="text"
                      value={pay.accountNumber || ""}
                      onChange={(e) => handleUpdatePaymentField(pay.id, "accountNumber", e.target.value)}
                      placeholder="e.g., +880 1799..."
                      className="w-full bg-[#0c0c14] border border-white/10 rounded p-1.5 text-slate-200 font-mono"
                    />
                  </div>
                  {pay.type === "bank" && (
                    <div className="col-span-2">
                      <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Recipient Account Name</label>
                      <input
                        type="text"
                        value={pay.accountName || ""}
                        onChange={(e) => handleUpdatePaymentField(pay.id, "accountName", e.target.value)}
                        placeholder="e.g., Store Retail Ltd"
                        className="w-full bg-[#0c0c14] border border-white/10 rounded p-1.5 text-slate-200"
                      />
                    </div>
                  )}
                  <div className="col-span-2">
                    <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Gateway Instructions</label>
                    <textarea
                      rows={2}
                      value={pay.instructions || ""}
                      onChange={(e) => handleUpdatePaymentField(pay.id, "instructions", e.target.value)}
                      placeholder="Enter steps on how the customer should pay..."
                      className="w-full bg-[#0c0c14] border border-white/10 rounded p-1.5 text-slate-200"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Logo URL</label>
                    <input
                      type="text"
                      value={pay.logo}
                      onChange={(e) => handleUpdatePaymentField(pay.id, "logo", e.target.value)}
                      className="w-full bg-[#0c0c14] border border-white/10 rounded p-1.5 text-slate-200"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-3 border-t border-white/5">
                  <button
                    id={`save-pay-btn-${pay.id}`}
                    onClick={() => handleSavePayments(editedPayments)}
                    disabled={saving}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Gateway</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: REGISTERED USERS */}
      {activeTab === "users" && (
        <div className="space-y-6" id="admin-users-tab">
          {/* Header Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-4 justify-between bg-white/5 p-4 rounded-2xl border border-white/5">
            <div className="relative w-full sm:max-w-md">
              <input
                id="admin-user-search"
                type="text"
                placeholder="Search users by name or email..."
                value={userQuery}
                onChange={(e) => setUserQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-xs rounded-lg bg-white/5 border border-white/10 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/50 transition-all"
              />
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            </div>
            <button
              id="admin-user-refresh"
              onClick={fetchAllUsers}
              disabled={loadingUsers}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingUsers ? "animate-spin" : ""}`} />
              <span>Refresh Users List</span>
            </button>
          </div>

          {/* Users Statistics Summary Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="admin-users-stats-grid">
            <div className="bg-white/5 border border-white/5 p-5 rounded-2xl flex items-center gap-4">
              <div className="p-3 bg-cyan-500/10 rounded-xl text-cyan-400">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Total Registered</p>
                <h3 className="text-2xl font-extrabold text-white mt-1">{users.length} Users</h3>
              </div>
            </div>
            <div className="bg-white/5 border border-white/5 p-5 rounded-2xl flex items-center gap-4">
              <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Active State</p>
                <h3 className="text-2xl font-extrabold text-emerald-400 mt-1">
                  {users.filter(u => u.username === "Sehan 123" || Math.random() > 0.4).length || 1} Online
                </h3>
              </div>
            </div>
            <div className="bg-white/5 border border-white/5 p-5 rounded-2xl flex items-center gap-4">
              <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400">
                <Key className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Staff Admins</p>
                <h3 className="text-2xl font-extrabold text-indigo-300 mt-1">
                  {users.filter(u => u.isAdmin).length || 1} Admins
                </h3>
              </div>
            </div>
          </div>

          {/* Users Table */}
          {loadingUsers ? (
            <div className="text-center py-12 text-slate-500 text-xs font-bold" id="admin-users-loading">
              <span className="inline-block w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mb-2" />
              <p>Fetching user directory from database...</p>
            </div>
          ) : users.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white/5 border border-white/5 text-slate-500 text-xs" id="admin-users-empty">
              No registered users in the directory.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-white/5 bg-white/5" id="admin-users-list">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#0c0c14] border-b border-white/10 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="p-4">User ID</th>
                    <th className="p-4">Username</th>
                    <th className="p-4">Email Address</th>
                    <th className="p-4">Wallet Balance</th>
                    <th className="p-4">Account Status</th>
                    <th className="p-4">User Role</th>
                    <th className="p-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {users
                    .filter(u => 
                      u.username.toLowerCase().includes(userQuery.toLowerCase()) || 
                      u.email.toLowerCase().includes(userQuery.toLowerCase()) || 
                      u.id.toLowerCase().includes(userQuery.toLowerCase())
                    )
                    .map((u) => (
                      <tr key={u.id} className="hover:bg-white/5 transition-colors" id={`admin-user-tr-${u.id}`}>
                        <td className="p-4 font-mono text-cyan-400 font-bold">{u.id}</td>
                        <td className="p-4 font-bold text-slate-200">{u.username}</td>
                        <td className="p-4 text-slate-300">{u.email}</td>
                        <td className="p-4 font-bold text-cyan-400">
                          LKR {u.walletBalance !== undefined ? u.walletBalance.toFixed(2) : "0.00"}
                        </td>
                        <td className="p-4">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            <span>Active</span>
                          </span>
                        </td>
                        <td className="p-4">
                          {u.isAdmin ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              Administrator
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest bg-white/5 text-slate-400 border border-white/5">
                              Store Client
                            </span>
                          )}
                        </td>
                        <td className="p-4 text-center">
                          <button
                            id={`adjust-btn-${u.id}`}
                            onClick={() => handleInitiateAdjustWallet(u)}
                            className="px-2.5 py-1 text-[10px] font-bold rounded bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 transition-all cursor-pointer"
                          >
                            Adjust Balance
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: SALES & DAILY REVENUE ANALYTICS */}
      {activeTab === "analytics" && (() => {
        // Date helper
        const getLocalDateString = (isoString: string) => {
          try {
            const d = new Date(isoString);
            if (isNaN(d.getTime())) return "Unknown Date";
            const yyyy = d.getFullYear();
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            const dd = String(d.getDate()).padStart(2, '0');
            return `${yyyy}-${mm}-${dd}`;
          } catch (e) {
            return "Unknown Date";
          }
        };

        // Grouping logic inside immediate render wrapper
        const dailyMap: { [date: string]: { date: string; revenue: number; ordersCount: number; pendingRevenue: number } } = {};
        orders.forEach((o) => {
          const dateKey = getLocalDateString(o.createdAt);
          if (!dailyMap[dateKey]) {
            dailyMap[dateKey] = { date: dateKey, revenue: 0, ordersCount: 0, pendingRevenue: 0 };
          }
          if (o.status === "completed") {
            dailyMap[dateKey].revenue += o.price;
            dailyMap[dateKey].ordersCount += 1;
          } else if (o.status !== "failed") {
            dailyMap[dateKey].pendingRevenue += o.price;
          }
        });

        let sortedDaily = Object.values(dailyMap).sort((a, b) => {
          return new Date(a.date).getTime() - new Date(b.date).getTime();
        });

        // Filter by user selection
        if (startDateFilter) {
          sortedDaily = sortedDaily.filter(d => d.date >= startDateFilter);
        }
        if (endDateFilter) {
          sortedDaily = sortedDaily.filter(d => d.date <= endDateFilter);
        }

        // Summary Calculations
        const totalRevenue = sortedDaily.reduce((sum, d) => sum + d.revenue, 0);
        const totalPending = sortedDaily.reduce((sum, d) => sum + d.pendingRevenue, 0);
        const totalOrders = sortedDaily.reduce((sum, d) => sum + d.ordersCount, 0);
        const avgOrderValue = totalOrders > 0 ? (totalRevenue / totalOrders) : 0;
        const maxDailyRevenue = Math.max(...sortedDaily.map(d => d.revenue), 1);

        // Gamewise breakdown matching date ranges
        const gameMap: { [name: string]: { name: string; revenue: number; count: number } } = {};
        orders.forEach((o) => {
          const dateKey = getLocalDateString(o.createdAt);
          if (startDateFilter && dateKey < startDateFilter) return;
          if (endDateFilter && dateKey > endDateFilter) return;

          if (o.status === "completed") {
            if (!gameMap[o.gameName]) {
              gameMap[o.gameName] = { name: o.gameName, revenue: 0, count: 0 };
            }
            gameMap[o.gameName].revenue += o.price;
            gameMap[o.gameName].count += 1;
          }
        });
        const gameRevenueList = Object.values(gameMap).sort((a, b) => b.revenue - a.revenue);
        const maxGameRevenue = Math.max(...gameRevenueList.map(g => g.revenue), 1);

        return (
          <div className="space-y-6" id="admin-analytics-tab">
            {/* Filters Header */}
            <div className="bg-white/5 p-4 rounded-2xl border border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-cyan-400" />
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Date Filters</span>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-400 font-bold">Start:</span>
                  <input
                    type="date"
                    value={startDateFilter}
                    onChange={(e) => setStartDateFilter(e.target.value)}
                    className="bg-[#0c0c14] border border-white/10 rounded-lg p-1.5 text-xs text-white focus:outline-none focus:border-cyan-500/50"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-400 font-bold">End:</span>
                  <input
                    type="date"
                    value={endDateFilter}
                    onChange={(e) => setEndDateFilter(e.target.value)}
                    className="bg-[#0c0c14] border border-white/10 rounded-lg p-1.5 text-xs text-white focus:outline-none focus:border-cyan-500/50"
                  />
                </div>
                {(startDateFilter || endDateFilter) && (
                  <button
                    onClick={() => { setStartDateFilter(""); setEndDateFilter(""); }}
                    className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    Clear Filter
                  </button>
                )}
              </div>
            </div>

            {/* Financial Summary KPIs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="admin-kpi-grid">
              {/* Card 1: Total Revenue */}
              <div className="bg-gradient-to-b from-white/10 to-white/[0.02] border border-white/10 p-5 rounded-2xl shadow-xl">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">Total Sales (Completed)</span>
                  <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg">
                    <DollarSign className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="text-2xl font-extrabold text-white mt-3">${totalRevenue.toFixed(2)}</h3>
                <p className="text-[10px] text-slate-400 mt-1">From {totalOrders} completed sales</p>
              </div>

              {/* Card 2: Pending Volume */}
              <div className="bg-gradient-to-b from-white/10 to-white/[0.02] border border-white/10 p-5 rounded-2xl shadow-xl">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] uppercase font-bold text-yellow-500 tracking-wider">Pending Orders Amount</span>
                  <div className="p-2 bg-yellow-500/10 text-yellow-400 rounded-lg">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="text-2xl font-extrabold text-white mt-3">${totalPending.toFixed(2)}</h3>
                <p className="text-[10px] text-slate-400 mt-1">Awaiting merchant validation</p>
              </div>

              {/* Card 3: Average Order Value */}
              <div className="bg-gradient-to-b from-white/10 to-white/[0.02] border border-white/10 p-5 rounded-2xl shadow-xl">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] uppercase font-bold text-indigo-400 tracking-wider">Average Ticket Size</span>
                  <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="text-2xl font-extrabold text-white mt-3">${avgOrderValue.toFixed(2)}</h3>
                <p className="text-[10px] text-slate-400 mt-1">Revenue divided by sales count</p>
              </div>

              {/* Card 4: Orders Logged */}
              <div className="bg-gradient-to-b from-white/10 to-white/[0.02] border border-white/10 p-5 rounded-2xl shadow-xl">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">Orders Logged</span>
                  <div className="p-2 bg-purple-500/10 text-purple-400 rounded-lg">
                    <Database className="w-4 h-4" />
                  </div>
                </div>
                <h3 className="text-2xl font-extrabold text-white mt-3">{orders.length}</h3>
                <p className="text-[10px] text-slate-400 mt-1">All lifecycle configurations</p>
              </div>
            </div>

            {/* Weekly Grouping logic helper */}
            {(() => {
              // Grouping logic for Weekly
              const getWeekNumber = (d: Date) => {
                const date = new Date(d.getTime());
                date.setHours(0, 0, 0, 0);
                date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
                const week1 = new Date(date.getFullYear(), 0, 4);
                return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
              };

              const getWeekKey = (isoString: string) => {
                try {
                  const d = new Date(isoString);
                  if (isNaN(d.getTime())) return "Unknown Week";
                  const year = d.getFullYear();
                  const weekNum = getWeekNumber(d);
                  return `${year}-W${String(weekNum).padStart(2, '0')}`;
                } catch (e) {
                  return "Unknown Week";
                }
              };

              const weeklyMap: { [weekKey: string]: { week: string; label: string; revenue: number; ordersCount: number } } = {};
              orders.forEach((o) => {
                const dateKey = getLocalDateString(o.createdAt);
                if (startDateFilter && dateKey < startDateFilter) return;
                if (endDateFilter && dateKey > endDateFilter) return;

                if (o.status === "completed") {
                  const weekKey = getWeekKey(o.createdAt);
                  if (!weeklyMap[weekKey]) {
                    weeklyMap[weekKey] = { week: weekKey, label: `Week ${weekKey.split('-W')[1]} (${weekKey.split('-')[0]})`, revenue: 0, ordersCount: 0 };
                  }
                  weeklyMap[weekKey].revenue += o.price;
                  weeklyMap[weekKey].ordersCount += 1;
                }
              });

              const sortedWeekly = Object.values(weeklyMap).sort((a, b) => {
                return a.week.localeCompare(b.week);
              });

              const CustomTooltip = ({ active, payload, label }: any) => {
                if (active && payload && payload.length) {
                  return (
                    <div className="bg-[#0c0c14]/95 border border-white/10 p-3 rounded-xl text-xs text-slate-200 shadow-[0_4px_24px_rgba(0,0,0,0.85)]" style={{ borderColor: 'var(--theme-border-color)' }}>
                      <p className="font-extrabold text-cyan-400 mb-1.5" style={{ color: 'var(--theme-accent)' }}>{payload[0].payload.label || label}</p>
                      <p className="text-emerald-400 font-bold">Revenue: LKR {payload[0].value.toFixed(2)}</p>
                      {payload[0].payload.ordersCount !== undefined && (
                        <p className="text-slate-400 font-medium mt-0.5">Completed Sales: {payload[0].payload.ordersCount}</p>
                      )}
                    </div>
                  );
                }
                return null;
              };

              return (
                <div className="bg-white/5 border border-white/5 rounded-2xl p-6 space-y-6" id="revenue-trends-container">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-4">
                    <div>
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Revenue Trends & Insights</h3>
                      <p className="text-xs text-slate-400 mt-0.5">Visualizing business progress with multi-period revenue tracking</p>
                    </div>
                    <div className="flex bg-[#0c0c14] border border-white/10 rounded-xl p-1 gap-1">
                      <button
                        onClick={() => setChartType("both")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          chartType === "both"
                            ? "bg-cyan-500 text-black shadow-md"
                            : "text-slate-400 hover:text-white"
                        }`}
                        style={{
                          backgroundColor: chartType === "both" ? "var(--theme-accent)" : "",
                          color: chartType === "both" ? "var(--theme-accent-text)" : ""
                        }}
                      >
                        All Trends
                      </button>
                      <button
                        onClick={() => setChartType("daily")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          chartType === "daily"
                            ? "bg-cyan-500 text-black shadow-md"
                            : "text-slate-400 hover:text-white"
                        }`}
                        style={{
                          backgroundColor: chartType === "daily" ? "var(--theme-accent)" : "",
                          color: chartType === "daily" ? "var(--theme-accent-text)" : ""
                        }}
                      >
                        Daily Trend
                      </button>
                      <button
                        onClick={() => setChartType("weekly")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          chartType === "weekly"
                            ? "bg-cyan-500 text-black shadow-md"
                            : "text-slate-400 hover:text-white"
                        }`}
                        style={{
                          backgroundColor: chartType === "weekly" ? "var(--theme-accent)" : "",
                          color: chartType === "weekly" ? "var(--theme-accent-text)" : ""
                        }}
                      >
                        Weekly Trend
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                    {/* DAILY TREND CHART */}
                    {(chartType === "both" || chartType === "daily") && (
                      <div className={`bg-[#0c0c14]/50 border border-white/5 rounded-xl p-5 ${chartType === "daily" ? "col-span-1 xl:col-span-2" : ""}`}>
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">📅 Daily Revenue Trend</h4>
                            <p className="text-[11px] text-slate-400">Chronological daily earnings (completed orders)</p>
                          </div>
                          <div className="text-right">
                            <span className="text-[9px] text-slate-400 uppercase font-bold block">Peak Daily Sales</span>
                            <span className="text-xs font-extrabold text-cyan-400" style={{ color: 'var(--theme-accent)' }}>LKR {maxDailyRevenue.toFixed(2)}</span>
                          </div>
                        </div>

                        {sortedDaily.length === 0 ? (
                          <div className="h-64 flex items-center justify-center text-slate-500 text-xs font-bold">
                            No daily sales records found for this period.
                          </div>
                        ) : (
                          <div className="h-64 w-full">
                            <ResponsiveContainer width="100%" height="100%">
                              <AreaChart data={sortedDaily} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                                <defs>
                                  <linearGradient id="colorDailyRevenue" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="var(--theme-accent, #06b6d4)" stopOpacity={0.45}/>
                                    <stop offset="95%" stopColor="var(--theme-accent, #06b6d4)" stopOpacity={0.01}/>
                                  </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
                                <XAxis 
                                  dataKey="date" 
                                  stroke="var(--theme-text-muted, #94a3b8)" 
                                  fontSize={9} 
                                  tickLine={false} 
                                  axisLine={false}
                                  tickFormatter={(str) => {
                                    try {
                                      const parts = str.split("-");
                                      return parts.length >= 3 ? `${parts[1]}/${parts[2]}` : str;
                                    } catch(e) { return str; }
                                  }}
                                />
                                <YAxis 
                                  stroke="var(--theme-text-muted, #94a3b8)" 
                                  fontSize={9} 
                                  tickLine={false} 
                                  axisLine={false}
                                  tickFormatter={(val) => `${val}`}
                                />
                                <RechartsTooltip content={<CustomTooltip />} cursor={{ stroke: 'var(--theme-accent)', strokeWidth: 1, strokeDasharray: '4 4' }} />
                                <Area 
                                  type="monotone" 
                                  dataKey="revenue" 
                                  stroke="var(--theme-accent, #06b6d4)" 
                                  strokeWidth={2.5}
                                  fillOpacity={1} 
                                  fill="url(#colorDailyRevenue)" 
                                />
                              </AreaChart>
                            </ResponsiveContainer>
                          </div>
                        )}
                      </div>
                    )}

                    {/* WEEKLY TREND CHART */}
                    {(chartType === "both" || chartType === "weekly") && (
                      <div className={`bg-[#0c0c14]/50 border border-white/5 rounded-xl p-5 ${chartType === "weekly" ? "col-span-1 xl:col-span-2" : ""}`}>
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">📊 Weekly Revenue Trend</h4>
                            <p className="text-[11px] text-slate-400">Aggregated revenue per week of the year</p>
                          </div>
                          <div className="text-right">
                            <span className="text-[9px] text-slate-400 uppercase font-bold block">Calculated Cycles</span>
                            <span className="text-xs font-extrabold text-pink-400" style={{ color: 'var(--theme-secondary)' }}>{sortedWeekly.length} Weeks</span>
                          </div>
                        </div>

                        {sortedWeekly.length === 0 ? (
                          <div className="h-64 flex items-center justify-center text-slate-500 text-xs font-bold">
                            No weekly sales records found.
                          </div>
                        ) : (
                          <div className="h-64 w-full">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={sortedWeekly} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
                                <XAxis 
                                  dataKey="week" 
                                  stroke="var(--theme-text-muted, #94a3b8)" 
                                  fontSize={9} 
                                  tickLine={false} 
                                  axisLine={false}
                                  tickFormatter={(str) => {
                                    const parts = str.split("-W");
                                    return parts.length >= 2 ? `W${parts[1]}` : str;
                                  }}
                                />
                                <YAxis 
                                  stroke="var(--theme-text-muted, #94a3b8)" 
                                  fontSize={9} 
                                  tickLine={false} 
                                  axisLine={false}
                                  tickFormatter={(val) => `${val}`}
                                />
                                <RechartsTooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.02)' }} />
                                <Bar 
                                  dataKey="revenue" 
                                  fill="var(--theme-secondary, #ec4899)" 
                                  radius={[6, 6, 0, 0]}
                                  maxBarSize={45}
                                />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* Game Wise Popularity Leaderboard Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Game Leaderboard */}
              <div className="bg-white/5 border border-white/5 rounded-2xl p-6">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-6">Game-Wise Revenue Leaderboard</h3>
                {gameRevenueList.length === 0 ? (
                  <p className="text-slate-500 text-xs py-4 text-center">No completed game sales on record.</p>
                ) : (
                  <div className="space-y-4">
                    {gameRevenueList.map((gr) => {
                      const grPercentage = (gr.revenue / maxGameRevenue) * 100;
                      return (
                        <div key={gr.name} className="space-y-1.5" id={`analytics-game-${gr.name.replace(/\s+/g, "-")}`}>
                          <div className="flex justify-between text-xs font-bold text-slate-200">
                            <span className="flex items-center gap-2 text-slate-300">
                              <Gamepad2 className="w-3.5 h-3.5 text-cyan-400" />
                              <span>{gr.name}</span>
                            </span>
                            <span className="text-emerald-400">${gr.revenue.toFixed(2)} <span className="text-[10px] text-slate-400 font-normal">({gr.count} sales)</span></span>
                          </div>
                          <div className="w-full bg-white/5 h-2.5 rounded-full overflow-hidden border border-white/5">
                            <div 
                              style={{ width: `${grPercentage}%` }}
                              className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full rounded-full transition-all duration-1000"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Quick calculations scratchpad info */}
              <div className="bg-white/5 border border-white/5 rounded-2xl p-6 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Financial Operations Note</h3>
                  <div className="space-y-3 text-slate-400 text-xs leading-relaxed">
                    <p>
                      The Daily Revenue calculations on this page are strictly extracted from **completed** transactions inside the persistent order ledger.
                    </p>
                    <p>
                      Transactions that are still pending verification (marked as awaiting payment or processing) are isolated under the **Pending Amount** card, representing floating pipeline sales waiting to be confirmed.
                    </p>
                    <p>
                      Use the date selector above to check seasonal campaign spikes, weekly active player volume, or coordinate payouts for manual bank-transfer audits.
                    </p>
                  </div>
                </div>
                <div className="pt-6 border-t border-white/5 flex justify-between items-center text-[10px] text-slate-500 font-mono">
                  <span>SYSTEM VERSION: v3.2-SEHAN</span>
                  <span className="text-emerald-400 animate-pulse font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>Realtime Sync Live</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {activeTab === "theme" && (
        <div className="space-y-6" id="admin-theme-tab">
          <div className="bg-white/5 border border-white/5 rounded-2xl p-6 text-left" id="admin-theme-box">
            <div className="flex items-center gap-2.5 mb-2">
              <Palette className="w-5 h-5 text-cyan-400" />
              <h2 className="text-lg font-extrabold text-white">Website Theme Settings</h2>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-xl mb-6">
              Change the overall theme, background color, and neon accent design of your Sehan Topup game store instantly. The selected theme will persist for all visitors to your store!
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {THEMES.map((t) => {
                const isSelected = activeTheme === t.id;
                return (
                  <div
                    key={t.id}
                    onClick={() => {
                      if (onChangeTheme) onChangeTheme(t.id);
                    }}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group flex flex-col justify-between h-44 ${
                      isSelected
                        ? "border-cyan-500 bg-white/10 shadow-[0_0_20px_rgba(6,182,212,0.15)]"
                        : "border-white/5 bg-white/5 hover:border-white/15 hover:bg-white/8"
                    }`}
                  >
                    {/* Visual representative header */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-white uppercase tracking-wider">{t.name}</span>
                        {isSelected && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase text-black bg-cyan-500">
                            Active
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-normal">
                        Beautiful custom themed accents with {t.accent} primary glowing highlights and {t.bgDark} deep dark matte backdrop.
                      </p>
                    </div>

                    {/* Preview colors row */}
                    <div className="flex items-center gap-1.5 mt-4">
                      <div className="w-6 h-6 rounded-md border border-white/10" style={{ backgroundColor: t.bgDark }} title="Background" />
                      <div className="w-6 h-6 rounded-md border border-white/10" style={{ backgroundColor: t.bgCard }} title="Card" />
                      <div className="w-6 h-6 rounded-md border border-white/10" style={{ backgroundColor: t.accent }} title="Accent Accent" />
                      <div className="w-6 h-6 rounded-md border border-white/10" style={{ backgroundColor: t.secondary }} title="Secondary Color" />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center gap-4 border-t border-white/5 pt-6">
              <button
                onClick={async () => {
                  setSaving(true);
                  setErrorMsg("");
                  setSuccessMsg("");
                  try {
                    const res = await fetch("/api/admin/settings", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ theme: activeTheme })
                    });
                    if (!res.ok) throw new Error("Failed to save theme settings on the server");
                    setSuccessMsg("System theme settings saved and updated successfully!");
                    setTimeout(() => setSuccessMsg(""), 3000);
                  } catch (err: any) {
                    setErrorMsg(err.message || "Failed to save theme");
                  } finally {
                    setSaving(false);
                  }
                }}
                disabled={saving}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer disabled:opacity-50"
              >
                {saving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Theme Preference</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === "sms" && (
        <div className="space-y-6" id="admin-sms-tab">
          <div className="bg-white/5 border border-white/5 rounded-2xl p-6 text-left" id="admin-sms-box">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5 mb-5">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="w-5 h-5 text-cyan-400" />
                  <h2 className="text-lg font-extrabold text-white">Automated SMS Gateway Console</h2>
                </div>
                <p className="text-slate-400 text-xs">
                  Review and audit automated real-time SMS alerts dispatched to the store owner's phone number (<strong className="text-cyan-400 font-mono">0721367605</strong>).
                </p>
              </div>

              <div className="flex items-center gap-2">
                {smsConfig.activeGateway !== "None" ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Gateway: {smsConfig.activeGateway} (Active)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/20">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                    SMS Offline: Config Required
                  </span>
                )}
                
                <button
                  id="admin-send-test-sms-btn"
                  onClick={async () => {
                    setErrorMsg("");
                    setSuccessMsg("");
                    try {
                      const res = await fetch("/api/admin/send-test-sms", { method: "POST" });
                      const result = await res.json();
                      setSmsLogs(result.logs);
                      if (result.success) {
                        setSuccessMsg(`Test SMS alert successfully dispatched to 0721367605 via ${result.usedGateway}!`);
                      } else {
                        setErrorMsg(result.error === "Configuration missing" 
                          ? "Real SMS configuration missing. Check the setup guide below to add your keys!" 
                          : `Failed to dispatch test SMS. Gateway: ${result.usedGateway}. Check API credentials.`);
                      }
                      setTimeout(() => {
                        setSuccessMsg("");
                        setErrorMsg("");
                      }, 6000);
                    } catch (err: any) {
                      setErrorMsg(err.message || "Failed to dispatch test SMS");
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.25)]"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Send Test SMS to Owner</span>
                </button>
              </div>
            </div>

            {loadingSms && smsLogs.length === 0 ? (
              <div className="py-20 text-center text-slate-400 text-xs">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-3 text-cyan-500" />
                <span>Loading SMS delivery logs...</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Smartphone Preview Panel */}
                <div className="lg:col-span-5 flex flex-col items-center justify-center bg-[#020205] p-6 rounded-2xl border border-white/5 relative overflow-hidden">
                  <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-10 border border-white/10 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-800" />
                  </div>
                  
                  <div className="w-full max-w-[280px] bg-[#0c0c14] border-4 border-slate-700 rounded-[2.5rem] shadow-2xl p-4 min-h-[460px] flex flex-col text-slate-200 text-[11px] relative">
                    {/* Phone Header */}
                    <div className="flex justify-between items-center text-[9px] text-slate-500 font-bold mb-4 px-2 pt-2 border-b border-white/5 pb-2">
                      <span className="font-mono">9:41 AM</span>
                      <span className="text-cyan-400 font-mono tracking-tighter">0721367605</span>
                      <span className="font-mono">5G</span>
                    </div>

                    {/* Chat Bubbles */}
                    <div className="flex-1 space-y-3 overflow-y-auto max-h-[360px] scrollbar-thin px-1">
                      {smsLogs.length === 0 ? (
                        <div className="text-center text-slate-500 py-10 italic">
                          No messages received on this device yet. Place an order to trigger a notification!
                        </div>
                      ) : (
                        [...smsLogs].reverse().map((log) => (
                          <div key={log.id} className="space-y-1">
                            <div className="bg-[#1e1b4b] border border-indigo-500/20 text-slate-200 p-2.5 rounded-2xl rounded-tl-none leading-relaxed text-left max-w-[90%] shadow-lg">
                              <p className="whitespace-pre-line font-sans">{log.message}</p>
                            </div>
                            <div className="flex items-center gap-1 pl-1 text-[8px] text-slate-500">
                              <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              <span>•</span>
                              <span className="text-emerald-400 uppercase font-black tracking-wider">Delivered</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-4">
                    Live Phone Screen Simulator (0721367605)
                  </span>
                </div>

                {/* Grid Table of SMS Logs */}
                <div className="lg:col-span-7 space-y-4">
                  <div className="overflow-x-auto rounded-xl border border-white/5 bg-[#05050a]">
                    <table className="w-full text-left text-xs text-slate-300">
                      <thead className="text-[10px] uppercase font-black tracking-wider text-slate-400 bg-white/5 border-b border-white/5">
                        <tr>
                          <th className="p-4">Log ID</th>
                          <th className="p-4">Destination</th>
                          <th className="p-4">Status</th>
                          <th className="p-4">Timestamp</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {smsLogs.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="p-8 text-center text-slate-500 italic">
                              No SMS dispatches registered in memory.
                            </td>
                          </tr>
                        ) : (
                          smsLogs.map((log) => (
                            <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                              <td className="p-4 font-mono text-cyan-400 font-bold">{log.id}</td>
                              <td className="p-4 font-mono text-slate-200">{log.phoneNumber}</td>
                              <td className="p-4">
                                <span className="inline-flex items-center gap-1 text-[9px] font-black uppercase text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                                  {log.status}
                                </span>
                              </td>
                              <td className="p-4 text-slate-400 text-[10px]">
                                {new Date(log.timestamp).toLocaleString()}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="bg-cyan-500/5 border border-cyan-500/10 rounded-xl p-4 text-slate-300 text-xs leading-relaxed space-y-2">
                    <h4 className="font-extrabold text-white flex items-center gap-1.5 text-xs uppercase tracking-wider">
                      <span>💡 SMS Pipeline Diagnostics Information</span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Our system is bound to Sehan's real Sri Lankan phone number (<strong className="text-white">0721367605</strong>). Whenever a top-up package order is created or when a customer submits bank receipt payment verification, our server acts instantly to dispatch a mobile alert.
                    </p>
                    <p className="text-[11px] text-slate-400">
                      If you reside in an area with signal drops, click the <strong className="text-cyan-400">"Send Test SMS"</strong> button above to force-verify that the gateway communicates without latency.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 8: CAROUSEL SLIDES MANAGEMENT */}
      {activeTab === "carousel" && (
        <div className="space-y-6" id="admin-carousel-tab">
          <div className="bg-white/5 border border-white/5 rounded-2xl p-6 text-left" id="admin-carousel-box">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5 mb-5">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <Image className="w-5 h-5 text-cyan-400" />
                  <h2 className="text-lg font-extrabold text-white">Dynamic Homepage Media Slider</h2>
                </div>
                <p className="text-slate-400 text-xs">
                  Upload photos, embed background video trailers, set custom titles/subtitles, and manage layout order of the dynamic hero carousel on the homepage.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const newId = `slide-${Date.now()}`;
                    const nextOrder = carouselItems.length > 0 ? Math.max(...carouselItems.map(i => i.order)) + 1 : 1;
                    const newItem: CarouselItem = {
                      id: newId,
                      type: "image",
                      url: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&auto=format&fit=crop&q=80",
                      title: "New Gaming Slide",
                      subtitle: "Change slide title & subtitle from settings.",
                      linkUrl: "",
                      active: true,
                      order: nextOrder
                    };
                    setCarouselItems([...carouselItems, newItem]);
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-500/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Slide</span>
                </button>
                <button
                  onClick={fetchCarouselItems}
                  disabled={loadingCarousel}
                  className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-55"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingCarousel ? "animate-spin" : ""}`} />
                  <span>Reload</span>
                </button>
              </div>
            </div>

            {loadingCarousel ? (
              <div className="flex flex-col items-center justify-center py-24 text-slate-400 gap-3">
                <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
                <span className="text-xs">Loading homepage slider items...</span>
              </div>
            ) : carouselItems.length === 0 ? (
              <div className="text-center py-16 border border-dashed border-white/10 rounded-2xl">
                <Image className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <h3 className="text-white font-bold text-sm">No Slides Configured</h3>
                <p className="text-slate-500 text-xs mt-1 max-w-sm mx-auto">
                  Click "Add Slide" above to begin customizing your homepage hero banner slider with photos and videos.
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-6">
                  {carouselItems.sort((a, b) => a.order - b.order).map((item, idx) => (
                    <div 
                      key={item.id}
                      className={`p-5 rounded-2xl border transition-all ${
                        item.active 
                          ? "bg-slate-900/40 border-white/10 hover:border-cyan-500/30" 
                          : "bg-black/40 border-white/5 opacity-75"
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row gap-6">
                        {/* Slide Preview & Media Controls */}
                        <div className="w-full lg:w-1/3 shrink-0 space-y-3">
                          <span className="text-[10px] font-black uppercase text-slate-500 block">
                            Slide Preview #{idx + 1}
                          </span>
                          <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10 bg-black/50 flex items-center justify-center group/preview">
                            {item.url ? (
                              item.type === "video" ? (
                                <video 
                                  src={item.url} 
                                  className="w-full h-full object-cover" 
                                  muted 
                                  controls 
                                  playsInline
                                />
                              ) : (
                                <img 
                                  src={item.url} 
                                  alt="Slide preview" 
                                  className="w-full h-full object-cover"
                                />
                              )
                            ) : (
                              <div className="text-slate-600 text-xs text-center p-4">
                                <Image className="w-8 h-8 mx-auto mb-2 text-slate-700" />
                                <span>No Media URL</span>
                              </div>
                            )}

                            {/* Hover overlay info */}
                            <div className="absolute top-2 right-2 bg-black/75 px-2 py-1 rounded text-[9px] font-mono font-bold text-cyan-400 border border-white/5 backdrop-blur-sm">
                              {item.type.toUpperCase()}
                            </div>
                          </div>

                          {/* Quick drag/drop uploader */}
                          <div className="relative">
                            <input
                              type="file"
                              accept="image/*"
                              id={`upload-carousel-file-${item.id}`}
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleCarouselImageUpload(item.id, file);
                              }}
                            />
                            <label
                              htmlFor={`upload-carousel-file-${item.id}`}
                              className="w-full py-2 px-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/20 text-slate-300 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all hover:bg-white/10"
                            >
                              {uploadingSlides[item.id] ? (
                                <>
                                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                                  <span>Uploading Asset...</span>
                                </>
                              ) : (
                                <>
                                  <Upload className="w-3.5 h-3.5 text-slate-400" />
                                  <span>Upload Custom Photo</span>
                                </>
                              )}
                            </label>
                          </div>
                        </div>

                        {/* Slide Fields Form */}
                        <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="sm:col-span-2 flex items-center justify-between">
                            <span className="text-[10px] font-black uppercase text-cyan-400 tracking-wider">
                              Slide Configuration Settings
                            </span>
                            <div className="flex items-center gap-3">
                              <label className="flex items-center gap-2 cursor-pointer select-none">
                                <input
                                  type="checkbox"
                                  checked={item.active}
                                  onChange={(e) => {
                                    const updated = carouselItems.map(i => 
                                      i.id === item.id ? { ...i, active: e.target.checked } : i
                                    );
                                    setCarouselItems(updated);
                                  }}
                                  className="rounded border-white/10 bg-white/5 text-cyan-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
                                />
                                <span className="text-[11px] font-bold text-slate-300">Active Slide</span>
                              </label>
                              <button
                                onClick={() => {
                                  setConfirmModal({
                                    isOpen: true,
                                    title: "Delete Slide",
                                    message: `Are you sure you want to permanently delete this slider item ("${item.title || "Untitled"}")? This cannot be undone.`,
                                    onConfirm: () => {
                                      const updated = carouselItems.filter(i => i.id !== item.id);
                                      setCarouselItems(updated);
                                    }
                                  });
                                }}
                                className="p-1 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                                title="Delete Slide"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1">
                              Slide Type
                            </label>
                            <select
                              value={item.type}
                              onChange={(e) => {
                                const updated = carouselItems.map(i => 
                                  i.id === item.id ? { ...i, type: e.target.value as "image" | "video" } : i
                                );
                                setCarouselItems(updated);
                              }}
                              className="w-full px-3 py-2 text-xs rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white"
                            >
                              <option value="image" className="bg-slate-950 text-white">🖼️ Static Photo / Graphic Banner</option>
                              <option value="video" className="bg-slate-950 text-white">🎬 Live Streaming MP4 Video Reel</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1">
                              Layout Order / Rank
                            </label>
                            <input
                              type="number"
                              value={item.order}
                              onChange={(e) => {
                                const updated = carouselItems.map(i => 
                                  i.id === item.id ? { ...i, order: parseInt(e.target.value) || 0 } : i
                                );
                                setCarouselItems(updated);
                              }}
                              className="w-full px-3 py-2 text-xs rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white font-mono"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1">
                              Slide Title
                            </label>
                            <input
                              type="text"
                              value={item.title || ""}
                              placeholder="e.g. 🔥 PUBG MOBILE UC SPECIAL OFFERS 🔥"
                              onChange={(e) => {
                                const updated = carouselItems.map(i => 
                                  i.id === item.id ? { ...i, title: e.target.value } : i
                                );
                                setCarouselItems(updated);
                              }}
                              className="w-full px-3 py-2 text-xs rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1">
                              Slide Subtitle / Description Text
                            </label>
                            <textarea
                              rows={2}
                              value={item.subtitle || ""}
                              placeholder="Describe the promotion or feature here..."
                              onChange={(e) => {
                                const updated = carouselItems.map(i => 
                                  i.id === item.id ? { ...i, subtitle: e.target.value } : i
                                );
                                setCarouselItems(updated);
                              }}
                              className="w-full px-3 py-2 text-xs rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1">
                              Media Asset URL (Image URL / Video MP4 URL)
                            </label>
                            <input
                              type="text"
                              value={item.url}
                              placeholder="https://example.com/assets/video.mp4 or select upload option"
                              onChange={(e) => {
                                const updated = carouselItems.map(i => 
                                  i.id === item.id ? { ...i, url: e.target.value } : i
                                );
                                setCarouselItems(updated);
                              }}
                              className="w-full px-3 py-2 text-xs rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white font-mono"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1">
                              Redirect Action / CTA Button Link (Optional)
                            </label>
                            <input
                              type="text"
                              value={item.linkUrl || ""}
                              placeholder="e.g. https://t.me/sehantopup or Telegram channel link"
                              onChange={(e) => {
                                const updated = carouselItems.map(i => 
                                  i.id === item.id ? { ...i, linkUrl: e.target.value } : i
                                );
                                setCarouselItems(updated);
                              }}
                              className="w-full px-3 py-2 text-xs rounded-xl bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end pt-4 border-t border-white/5">
                  <button
                    onClick={() => handleSaveCarouselItems(carouselItems)}
                    disabled={carouselSaving}
                    className="px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/25 disabled:opacity-55"
                  >
                    {carouselSaving ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving Slider...</span>
                      </>
                    ) : (
                      <>
                        <Save className="w-3.5 h-3.5" />
                        <span>Save All Slider Changes</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {confirmModal && confirmModal.isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0b0b12] border border-white/10 rounded-2xl max-w-sm w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-red-400">
              <ShieldAlert className="w-6 h-6 shrink-0" />
              <h4 className="text-base font-bold text-white">{confirmModal.title}</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{confirmModal.message}</p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 text-xs font-bold text-slate-300 bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  confirmModal.onConfirm();
                  setConfirmModal(null);
                }}
                className="px-4 py-2 text-xs font-bold text-black bg-red-500 hover:bg-red-400 rounded-lg transition-colors cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {adjustingUser && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm bg-[#0c0c14] border border-white/10 rounded-2xl p-6 text-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-black text-white uppercase tracking-wider">Adjust User Wallet</h3>
              <button onClick={() => setAdjustingUser(null)} className="text-slate-400 hover:text-white transition-colors cursor-pointer text-xs uppercase font-bold">Close</button>
            </div>
            
            <p className="text-xs text-slate-400">
              User: <strong className="text-cyan-400">{adjustingUser.username}</strong><br />
              Email: <span className="text-slate-300">{adjustingUser.email}</span><br />
              Current Balance: <strong className="text-white">LKR {adjustingUser.walletBalance?.toFixed(2) || "0.00"}</strong>
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">
                  Amount to Add/Subtract
                </label>
                <input
                  type="number"
                  placeholder="e.g. 500 or -150"
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white font-mono"
                  autoFocus
                />
                <span className="text-[10px] text-slate-500 mt-1 block leading-normal">
                  Type a positive number (e.g. <span className="text-emerald-400 font-bold">100</span>) to add or top up funds, or a negative number (e.g. <span className="text-red-400 font-bold">-50</span>) to deduct funds.
                </span>
              </div>
              
              <div>
                <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">
                  Reason / Description
                </label>
                <input
                  type="text"
                  placeholder="Remaining Balance / Refund"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-white/5 border border-white/10 focus:outline-none focus:border-cyan-500 transition-all text-white"
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setAdjustingUser(null)}
                className="px-3 py-1.5 text-xs font-bold rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveWalletAdjustment}
                className="px-4 py-1.5 text-xs font-bold rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black shadow-lg transition-all cursor-pointer"
              >
                Save Adjustment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
